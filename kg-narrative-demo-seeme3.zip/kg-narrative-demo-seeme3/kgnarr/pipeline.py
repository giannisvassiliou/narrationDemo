"""Orchestration and persistence.

data/selections/<id>.json   a selected subgraph with its rule closure
data/runs/<id>.json         a narrative with its audited claims and metrics
data/gallery/<id>.json      prepared examples (see precompute.py)
data/annotations.jsonl      human labels, one line per saved correction
"""
from __future__ import annotations

import json
import logging
import re
import time
import uuid

from . import kg
from .config import SETTINGS
from .generate import MODES, generate
from .reasoner import LOCATED_IN, closure
from .selectors import SELECTORS, select
from .sources import get_source
from .sparql import SparqlError
from .verify import LABELS, attach_segments, metrics, verify

_ID = re.compile(r"^[A-Za-z0-9_-]{1,80}$")
log = logging.getLogger("kgnarr")


def _dir(name):
    path = SETTINGS.data_dir / name
    path.mkdir(parents=True, exist_ok=True)
    return path


def _save(folder, obj_id, obj):
    (_dir(folder) / f"{obj_id}.json").write_text(json.dumps(obj, ensure_ascii=False, indent=1),
                                                 encoding="utf-8")


def _load(folder, obj_id):
    if not _ID.match(obj_id or ""):
        raise ValueError("Bad id.")
    path = _dir(folder) / f"{obj_id}.json"
    if not path.exists():
        raise KeyError(f"No saved {folder.rstrip('s')} with id {obj_id}")
    return json.loads(path.read_text(encoding="utf-8"))


# ---------------------------------------------------------------- selection


def build_selection(source_name: str, seed_text: str, hops: int, selector: str, budget: int,
                    per_relation: int | None = 3) -> dict:
    if hops not in (1, 2, 3):
        raise ValueError("Hops must be 1, 2 or 3.")
    if not 3 <= budget <= 150:
        raise ValueError("Budget must be between 3 and 150 triples.")
    if selector not in SELECTORS:
        raise ValueError(f"Unknown selector: {selector}")
    if per_relation is not None and per_relation < 1:
        per_relation = None  # 0 or negative: no cap
    source = get_source(source_name)
    seed = source.resolve(seed_text)
    if not seed:
        raise KeyError(f"No {source.title} entity found for {seed_text!r}. "
                       "Use the English Wikipedia title, e.g. Albert_Einstein.")
    cand = kg.get_candidate(source, seed, hops)
    chosen, diag = select(cand, selector, budget, per_relation)
    nodes = cand["nodes"]

    ordered = sorted(chosen, key=lambda t: (t["hop"], nodes[t["s"]]["label"], t["p_label"],
                                            nodes[t["o"]]["label"]))
    triples = []
    for i, t in enumerate(ordered, start=1):
        o = nodes[t["o"]]
        triples.append({
            "tid": f"T{i}", "cid": t["id"], "s": t["s"], "p": t["p"], "o": t["o"], "hop": t["hop"],
            "s_label": nodes[t["s"]]["label"], "p_label": t["p_label"], "o_label": o["label"],
            "o_kind": o["kind"], "o_datatype": o.get("datatype", ""),
        })
    used = {t["s"] for t in chosen} | {t["o"] for t in chosen} | {seed}

    derived, closure_note = _derive(source, triples, {n: nodes[n]["label"] for n in used})
    diag["derived_triples"] = len(derived)
    popularity = None
    if not source.fixture:
        try:
            popularity = source.popularity(seed)
        except SparqlError:
            popularity = None

    selection = {
        "selection_id": uuid.uuid4().hex[:12],
        "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "source": source.name, "source_title": source.title,
        "seed": {"uri": seed, "label": nodes[seed]["label"]},
        "popularity": popularity,
        "hops": hops, "selector": selector, "selector_label": SELECTORS[selector][0], "budget": budget,
        "per_relation": per_relation,
        "triples": triples,
        "derived": derived, "closure_note": closure_note,
        "nodes": [{k: v for k, v in nodes[n].items()} for n in used],
        "diagnostics": diag,
    }
    _save("selections", selection["selection_id"], selection)
    return selection


def _derive(source, triples, node_labels):
    """Rule closure; a failed ontology lookup degrades to no derived triples."""
    try:
        axioms = source.ontology(triples)
    except SparqlError as exc:
        return [], f"Ontology lookup failed, so no rules were applied ({exc})."
    derived = closure(triples, node_labels, axioms)
    plabels = {t["p"]: t["p_label"] for t in triples}
    missing = sorted({d["p"] for d in derived if d["p"] not in plabels
                      and d["p"] not in (axioms["type_pred"], LOCATED_IN)})
    if missing:
        plabels.update(source.predicate_labels(missing))
    for d in derived:
        if d["p"] == axioms["type_pred"]:
            d["p_label"] = axioms["type_label"]
        elif d["p"] == LOCATED_IN:
            d["p_label"] = "located in"
        else:
            d["p_label"] = plabels.get(d["p"]) or kg.humanize_predicate(d["p"])
    return derived, None


# ---------------------------------------------------------------- narration


def narrate(selection_id: str, mode: str, sentences: int, selection: dict | None = None) -> dict:
    if mode not in MODES:
        raise ValueError(f"Unknown prompt: {mode}")
    if not 2 <= sentences <= 20:
        raise ValueError("Sentences must be between 2 and 20.")
    sel = selection or _load("selections", selection_id)
    source = get_source(sel["source"])
    triples = [] if mode == "closed_book" else sel["triples"]
    nodes = {n["id"]: n for n in sel["nodes"]}

    t0 = time.time()
    log.info("%s / %s: writing narrative", sel["seed"]["label"], mode)
    narrative, gen_usage = generate(sel["seed"]["label"], triples, mode, sentences)
    t1 = time.time()
    log.info("%s / %s: narrative written in %.1f s; auditing", sel["seed"]["label"], mode, t1 - t0)
    claims, ver_usage = verify(narrative, triples, sel["derived"], source, nodes)
    log.info("%s / %s: audit done in %.1f s (%d claims)", sel["seed"]["label"], mode, time.time() - t1, len(claims))
    attach_segments(narrative["sentences"], claims)

    run = {
        "run_id": uuid.uuid4().hex[:12],
        "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "selection_id": sel["selection_id"], "source": sel["source"],
        "seed": sel["seed"], "selector": sel["selector"], "hops": sel["hops"], "budget": sel["budget"],
        "mode": mode, "mode_label": MODES[mode],
        "model": SETTINGS.model, "verifier_model": SETTINGS.verifier_model, "mock": SETTINGS.mock_llm,
        "title": narrative["title"],
        "sentences": [dict(s, index=i) for i, s in enumerate(narrative["sentences"])],
        "claims": claims,
        "metrics": metrics(claims, len(triples)),
        "usage": {"generator": gen_usage, "verifier": ver_usage},
    }
    _save("runs", run["run_id"], run)
    return run


# ---------------------------------------------------------------- annotation


def annotate(run_id: str, claim_index: int, label: str, note: str = "", annotator: str = "") -> dict:
    if label not in LABELS:
        raise ValueError(f"Unknown label: {label}")
    run = _load_run(run_id)
    claims = {c["index"]: c for c in run["claims"]}
    if claim_index not in claims:
        raise KeyError(f"No claim {claim_index} in run {run_id}")
    claim = claims[claim_index]
    record = {
        "time": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "annotator": annotator.strip()[:60] or "anonymous",
        "run_id": run_id, "claim_index": claim_index,
        "source": run["source"], "seed": run["seed"]["uri"], "selector": run["selector"],
        "mode": run["mode"], "model": run["model"], "verifier_model": run["verifier_model"],
        "sentence": run["sentences"][claim["sentence"]]["text"],
        "claim": claim["claim"], "span": claim["span"], "evidence": claim["evidence"],
        "verifier_label": claim["verifier_label"],
        "auto_label": claim["label"], "human_label": label, "note": note.strip()[:1000],
    }
    with open(_dir("") / "annotations.jsonl", "a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")
    claim["human_label"] = label
    claim["human_note"] = record["note"]
    _save("runs", run_id, run)
    return {"ok": True, "claim_index": claim_index, "human_label": label}


def _load_run(run_id):
    """A run from data/runs, or from a gallery entry copied without its runs."""
    try:
        return _load("runs", run_id)
    except KeyError:
        for path in _dir("gallery").glob("*.json"):
            entry = json.loads(path.read_text(encoding="utf-8"))
            for lane in entry.get("lanes", []):
                if lane["run"]["run_id"] == run_id:
                    return lane["run"]
        raise


# ---------------------------------------------------------------- gallery


def save_gallery(entry: dict) -> None:
    _save("gallery", entry["id"], entry)


def list_gallery() -> list[dict]:
    items = []
    for path in sorted(_dir("gallery").glob("*.json")):
        try:
            e = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        items.append({k: e.get(k) for k in ("id", "title", "source", "preset", "popularity", "seed")})
    items.sort(key=lambda e: -((e.get("popularity") or {}).get("value") or 0))
    return items


def get_gallery(entry_id: str) -> dict:
    return _load("gallery", entry_id)
