"""Source registry."""
from __future__ import annotations

from ..config import SETTINGS
from .base import Source
from .dbpedia import DBpediaFixtureSource, DBpediaSource
from .wikidata import WikidataSource

_instances: dict[str, Source] = {}


def available_sources() -> list[dict]:
    if SETTINGS.offline:
        return [{"id": "dbpedia", "label": "DBpedia (offline fixture)"}]
    return [{"id": "dbpedia", "label": "DBpedia"}, {"id": "wikidata", "label": "Wikidata"}]


def get_source(name: str) -> Source:
    if name not in ("dbpedia", "wikidata"):
        raise ValueError(f"Unknown knowledge graph: {name}")
    if SETTINGS.offline and name != "dbpedia":
        raise ValueError("Offline mode only has the DBpedia fixture.")
    if name not in _instances:
        if name == "dbpedia":
            _instances[name] = DBpediaFixtureSource() if SETTINGS.offline else DBpediaSource()
        else:
            _instances[name] = WikidataSource()
    return _instances[name]
