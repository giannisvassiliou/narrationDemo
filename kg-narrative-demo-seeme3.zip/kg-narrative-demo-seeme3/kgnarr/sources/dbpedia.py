"""DBpedia source (dbo: predicates only)."""
from __future__ import annotations

import json
from collections import defaultdict

from ..config import ROOT, SETTINGS
from ..kg import finish, humanize_resource, literal_node, local_name
from ..sparql import Sparql
from .base import Source, check_iri, chunks, round_robin, sparql_string

DBO = "http://dbpedia.org/ontology/"
DBR = "http://dbpedia.org/resource/"
RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
RDFS = "http://www.w3.org/2000/01/rdf-schema#"
FIXTURES = ROOT / "fixtures"

EXCLUDED = tuple(DBO + p for p in (
    "wikiPageWikiLink", "wikiPageExternalLink", "wikiPageID", "wikiPageRevisionID",
    "wikiPageLength", "wikiPageRedirects", "wikiPageDisambiguates", "wikiPageOutDegree",
    "wikiPageInterLanguageLink", "abstract", "thumbnail", "wikiPageUsesTemplate",
))
# Place-of relations whose meaning survives moving up a containment chain
# (born in Ulm, Ulm in Germany => born in Germany).
PRESERVING = {DBO + p for p in (
    "birthPlace", "deathPlace", "restingPlace", "residence", "location", "headquarter",
)}
# Spatial containment relations.
CONTAINMENT = {DBO + p for p in (
    "country", "isPartOf", "federalState", "state", "region", "county", "district",
)}
CLASS_STOPLIST = {"http://www.w3.org/2002/07/owl#Thing", DBO + "Species", DBO + "Eukaryote"}


def _excluded_filter(var: str = "?p") -> str:
    return f"FILTER({var} NOT IN (" + ", ".join(f"<{p}>" for p in EXCLUDED) + "))"


def _dbo_filter(var: str = "?p") -> str:
    return f'FILTER(STRSTARTS(STR({var}), "{DBO}")) {_excluded_filter(var)}'


class DBpediaSource(Source):
    name = "dbpedia"
    title = "DBpedia"

    def __init__(self):
        self._sparql = None

    @property
    def sparql(self) -> Sparql:
        if self._sparql is None:
            self._sparql = Sparql(SETTINGS.dbpedia_endpoint, SETTINGS.data_dir / "sparql-cache")
        return self._sparql

    # ------------------------------------------------------------ naming

    @staticmethod
    def to_uri(text: str) -> str:
        text = text.strip()
        for prefix in ("https://dbpedia.org/page/", "http://dbpedia.org/page/",
                       "https://dbpedia.org/resource/"):
            if text.startswith(prefix):
                text = DBR + text[len(prefix):]
        if not text:
            raise ValueError("Empty entity name.")
        return check_iri(text if text.startswith("http://") else DBR + text.replace(" ", "_"))

    def resolve(self, text: str) -> str | None:
        uri = self.to_uri(text)
        rows = self.sparql.select(f"SELECT ?t WHERE {{ <{uri}> <{DBO}wikiPageRedirects> ?t }} LIMIT 1")
        if rows:
            uri = rows[0]["t"]["value"]
        return uri if self.sparql.ask(f"ASK {{ <{uri}> ?p ?o }}") else None

    # ------------------------------------------------------------ extraction

    def outgoing(self, subjects, per_node):
        rows = []
        for chunk in chunks(subjects, 25):
            values = " ".join(f"<{s}>" for s in chunk)
            query = f"""
SELECT ?s ?p ?o WHERE {{
  VALUES ?s {{ {values} }}
  ?s ?p ?o .
  {_dbo_filter()}
  FILTER( (isIRI(?o) && STRSTARTS(STR(?o), "{DBR}"))
       || (isLiteral(?o) && (lang(?o) = "" || langMatches(lang(?o), "en"))) )
}} LIMIT {min(10000, per_node * len(chunk) * 3)}"""
            by_subject = defaultdict(list)
            for r in self.sparql.select(query):
                by_subject[r["s"]["value"]].append((r["s"]["value"], r["p"]["value"], r["o"]))
            for s in chunk:
                ordered = sorted(by_subject.get(s, []), key=lambda t: (t[1], t[2]["value"]))
                rows.extend(round_robin(ordered, per_node))
        return rows

    def incoming(self, seed, limit):
        """Incoming edges spread over relations: count subjects per relation, then take
        an equal share from each, most notable (longest Wikipedia article) first."""
        counts = self.sparql.select(f"""
SELECT ?p (COUNT(?s) AS ?n) WHERE {{
  ?s ?p <{seed}> .
  {_dbo_filter()}
  FILTER(STRSTARTS(STR(?s), "{DBR}"))
}} GROUP BY ?p ORDER BY DESC(?n) LIMIT 25""")
        preds = [r["p"]["value"] for r in counts]
        if not preds:
            return []
        share = max(3, limit // len(preds))
        rows = []
        for p in preds:
            result = self.sparql.select(f"""
SELECT ?s WHERE {{
  ?s <{p}> <{seed}> .
  FILTER(STRSTARTS(STR(?s), "{DBR}"))
  OPTIONAL {{ ?s <{DBO}wikiPageLength> ?len }}
}} ORDER BY DESC(?len) ?s LIMIT {share}""")
            rows.extend((r["s"]["value"], p, {"type": "uri", "value": seed}) for r in result)
        return rows[:limit]

    def labels(self, uris):
        out = {}
        for chunk in chunks(list(uris), 80):
            values = " ".join(f"<{u}>" for u in chunk)
            for r in self.sparql.select(
                f"SELECT ?s ?l WHERE {{ VALUES ?s {{ {values} }} ?s <{RDFS}label> ?l "
                f'FILTER(langMatches(lang(?l), "en")) }}'
            ):
                out.setdefault(r["s"]["value"], r["l"]["value"])
        return out

    def predicate_labels(self, preds):
        return {}  # humanized local names read well for dbo:

    # ------------------------------------------------------------ ontology

    def ontology(self, triples):
        preds = sorted({t["p"] for t in triples})
        subprop, domain, rng, subclass = defaultdict(list), defaultdict(list), defaultdict(list), {}
        if preds:
            values = " ".join(f"<{p}>" for p in preds)
            for r in self.sparql.select(
                f"SELECT ?p ?sup WHERE {{ VALUES ?p {{ {values} }} ?p <{RDFS}subPropertyOf>+ ?sup "
                f'FILTER(STRSTARTS(STR(?sup), "{DBO}")) }}'
            ):
                subprop[r["p"]["value"]].append(r["sup"]["value"])
            for r in self.sparql.select(
                f"SELECT ?p ?k ?c WHERE {{ VALUES ?p {{ {values} }} "
                f"VALUES ?k {{ <{RDFS}domain> <{RDFS}range> }} ?p ?k ?c "
                f'FILTER(STRSTARTS(STR(?c), "{DBO}")) }}'
            ):
                target = domain if r["k"]["value"].endswith("domain") else rng
                target[r["p"]["value"]].append(r["c"]["value"])
        classes = sorted({c for cs in list(domain.values()) + list(rng.values()) for c in cs})
        if classes:
            values = " ".join(f"<{c}>" for c in classes)
            sup = defaultdict(list)
            for r in self.sparql.select(
                f"SELECT ?c ?sup WHERE {{ VALUES ?c {{ {values} }} ?c <{RDFS}subClassOf>+ ?sup "
                f'FILTER(STRSTARTS(STR(?sup), "{DBO}")) }}'
            ):
                sup[r["c"]["value"]].append(r["sup"]["value"])
            subclass = dict(sup)
        all_classes = set(classes) | {s for v in subclass.values() for s in v}
        return {
            "type_pred": RDF_TYPE, "type_label": "is a",
            "subprop": dict(subprop), "domain": dict(domain), "range": dict(rng),
            "subclass": subclass, "preserving": PRESERVING, "containment": CONTAINMENT,
            "stoplist": CLASS_STOPLIST, "labels": self.labels(sorted(all_classes)),
        }

    # ------------------------------------------------------------ oracle

    def oracle_direct(self, s, o):
        rows = self.sparql.select(f"""
SELECT ?s ?p ?o WHERE {{
  {{ <{s}> ?p <{o}> . BIND(<{s}> AS ?s) BIND(<{o}> AS ?o) }}
  UNION {{ <{o}> ?p <{s}> . BIND(<{o}> AS ?s) BIND(<{s}> AS ?o) }}
  {_dbo_filter()}
}} LIMIT 5""")
        return [(r["s"]["value"], r["p"]["value"], r["o"]["value"]) for r in rows]

    def oracle_path(self, s, o):
        rows = self.sparql.select(f"""
SELECT ?p1 ?m ?p2 WHERE {{
  <{s}> ?p1 ?m . ?m ?p2 <{o}> .
  FILTER(isIRI(?m) && ?m != <{s}> && ?m != <{o}>)
  {_dbo_filter("?p1")} {_dbo_filter("?p2")}
}} LIMIT 3""")
        return [[(s, r["p1"]["value"], r["m"]["value"]), (r["m"]["value"], r["p2"]["value"], o)]
                for r in rows]

    def oracle_literal(self, s, literal):
        lit = sparql_string(literal, 100)
        rows = self.sparql.select(f"""
SELECT ?p ?v WHERE {{
  <{s}> ?p ?v . FILTER(isLiteral(?v))
  {_dbo_filter()}
  FILTER(CONTAINS(LCASE(STR(?v)), LCASE("{lit}")))
}} LIMIT 5""")
        return [(s, r["p"]["value"], r["v"]["value"]) for r in rows]

    def popularity(self, uri):
        rows = self.sparql.select(
            f"SELECT (COUNT(?x) AS ?n) WHERE {{ ?x <{DBO}wikiPageWikiLink> <{uri}> }}")
        return {"measure": "incoming Wikipedia links", "value": int(rows[0]["n"]["value"])} if rows else None


class DBpediaFixtureSource(DBpediaSource):
    """Offline stand-in: fixtures/<Name>.json plus fixtures/ontology_dbpedia.json.
    No oracle: unsupported claims stay 'unchecked'."""

    fixture = True
    name = "dbpedia"
    title = "DBpedia (offline fixture)"

    def resolve(self, text):
        uri = self.to_uri(text)
        return uri if (FIXTURES / f"{local_name(uri)}.json").exists() else None

    def labels(self, uris):
        return {u: humanize_resource(u) for u in uris}

    def fixture_candidate(self, seed, hops):
        data = json.loads((FIXTURES / f"{local_name(seed)}.json").read_text(encoding="utf-8"))
        nodes = {seed: {"id": seed, "kind": "seed", "hop": 0, "label": humanize_resource(seed)}}
        triples = []
        for s, p, o, hop in data["triples"]:
            if hop > hops:
                continue
            s_uri, p_uri = DBR + s, DBO + p
            if isinstance(o, dict):
                term = {"type": "literal", "value": o["literal"],
                        "datatype": "http://www.w3.org/2001/XMLSchema#" + o.get("datatype", "string")}
                lit = literal_node(s_uri, p_uri, term, hop)
                nodes[lit["id"]] = lit
                o_id = lit["id"]
            else:
                o_id = DBR + o
            for n in (s_uri, o_id):
                if n not in nodes:
                    nodes[n] = {"id": n, "kind": "entity", "hop": hop, "label": humanize_resource(n)}
            triples.append({"s": s_uri, "p": p_uri, "o": o_id, "hop": hop})
        return finish(self, seed, hops, nodes, triples)

    def ontology(self, triples):
        data = json.loads((FIXTURES / "ontology_dbpedia.json").read_text(encoding="utf-8"))
        preds = {t["p"] for t in triples}
        pick = lambda m: {DBO + k: [DBO + c for c in v] for k, v in m.items() if DBO + k in preds}
        subclass = {DBO + k: [DBO + c for c in v] for k, v in data["subclass"].items()}
        classes = set(subclass) | {c for v in subclass.values() for c in v}
        return {
            "type_pred": RDF_TYPE, "type_label": "is a",
            "subprop": pick(data["subprop"]), "domain": pick(data["domain"]), "range": pick(data["range"]),
            "subclass": subclass, "preserving": PRESERVING, "containment": CONTAINMENT,
            "stoplist": CLASS_STOPLIST, "labels": {c: humanize_resource(c) for c in classes},
        }

    def popularity(self, uri):
        return None
