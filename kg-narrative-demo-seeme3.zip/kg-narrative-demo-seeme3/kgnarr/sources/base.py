"""Knowledge-graph sources.

A source knows how to resolve a seed, fetch neighbourhood triples, fetch the
ontology axioms the reasoner needs, and look facts up in the full KG (the
oracle used to separate leakage from facts missing in the KG).
"""
from __future__ import annotations

import re

_BAD_IRI_CHARS = re.compile(r'[\s<>"{}|\\^`]')


def check_iri(uri: str) -> str:
    if not uri or _BAD_IRI_CHARS.search(uri):
        raise ValueError(f"Not a usable entity name: {uri!r}")
    return uri


def sparql_string(text: str, limit: int = 200) -> str:
    """Escape text for use inside a SPARQL double-quoted literal."""
    return text.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ").replace("\r", " ")[:limit]


def chunks(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def round_robin(rows: list, cap: int, key=lambda r: r[1]) -> list:
    """Keep at most `cap` rows, taking one per predicate in turn, so a node with
    many values for one predicate does not crowd out its other predicates."""
    groups: dict = {}
    for r in rows:
        groups.setdefault(key(r), []).append(r)
    out, i = [], 0
    ordered = [groups[k] for k in sorted(groups)]
    while len(out) < cap and any(i < len(g) for g in ordered):
        for g in ordered:
            if i < len(g) and len(out) < cap:
                out.append(g[i])
        i += 1
    return out


class Source:
    """Interface. Methods return plain Python data; SPARQL results are cached."""

    name = "base"
    title = "Base"
    fixture = False          # True for the offline fixture source
    type_label = "is a"

    def resolve(self, text: str) -> str | None: raise NotImplementedError
    def outgoing(self, subjects: list[str], per_node: int) -> list: raise NotImplementedError
    def incoming(self, seed: str, limit: int) -> list: raise NotImplementedError
    def labels(self, uris: list[str]) -> dict[str, str]: raise NotImplementedError
    def predicate_labels(self, preds: list[str]) -> dict[str, str]: raise NotImplementedError

    def ontology(self, triples: list[dict]) -> dict:
        """Axioms for the reasoner: see reasoner.py for the expected keys."""
        raise NotImplementedError

    # Oracle lookups in the full KG. Each returns a list of (s, p, o) tuples.
    def oracle_direct(self, s: str, o: str) -> list[tuple]: raise NotImplementedError
    def oracle_path(self, s: str, o: str) -> list[list[tuple]]: raise NotImplementedError
    def oracle_literal(self, s: str, literal: str) -> list[tuple]: raise NotImplementedError

    def popularity(self, uri: str) -> dict | None:
        return None
