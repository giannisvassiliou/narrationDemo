"""Wikidata source (truthy wdt: statements).

Seeds are given as English Wikipedia titles (same as DBpedia, so the two KGs
can be compared on the same seed list) or as Q-ids.
"""
from __future__ import annotations

import re
from collections import defaultdict

from ..config import SETTINGS
from ..sparql import Sparql
from .base import Source, check_iri, chunks, round_robin, sparql_string

WD = "http://www.wikidata.org/entity/"
WDT = "http://www.wikidata.org/prop/direct/"
PREFIXES = (
    "PREFIX wikibase: <http://wikiba.se/ontology#>\n"
    "PREFIX schema: <http://schema.org/>\n"
    "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n"
    f"PREFIX wdt: <{WDT}>\n"
)
# Statement types kept. External identifiers, URLs, media and shapes are noise here.
KEPT_TYPES = "wikibase:WikibaseItem, wikibase:Time, wikibase:Quantity, wikibase:String, wikibase:Monolingualtext"
# Bookkeeping and flood properties.
EXCLUDED = tuple(WDT + p for p in (
    "P373", "P910", "P1424", "P1343", "P5008", "P2860", "P921", "P6104", "P1889", "P5125", "P935",
))
# Incoming edges also skip authorship (scholarly articles flood hubs).
EXCLUDED_IN = EXCLUDED + (WDT + "P50",)

PRESERVING = {WDT + p for p in ("P19", "P20", "P119", "P551", "P159", "P276", "P740")}
CONTAINMENT = {WDT + p for p in ("P131", "P17")}
CLASS_STOPLIST = {WD + q for q in ("Q35120", "Q488383", "Q7184903", "Q151885", "Q16686448")}


def _not_in(var, preds):
    return f"FILTER({var} NOT IN (" + ", ".join(f"<{p}>" for p in preds) + "))"


def _wdt_filter(var="?p"):
    return f'FILTER(STRSTARTS(STR({var}), "{WDT}")) {_not_in(var, EXCLUDED)}'


class WikidataSource(Source):
    name = "wikidata"
    title = "Wikidata"
    type_label = "instance of"

    def __init__(self):
        self._sparql = None

    @property
    def sparql(self) -> Sparql:
        if self._sparql is None:
            self._sparql = Sparql(SETTINGS.wikidata_endpoint, SETTINGS.data_dir / "sparql-cache",
                                  send_format=False)
        return self._sparql

    def _select(self, body: str):
        return self.sparql.select(PREFIXES + body)

    # ------------------------------------------------------------ naming

    def resolve(self, text: str) -> str | None:
        text = text.strip()
        m = re.search(r"(Q\d+)$", text)
        if m and (text == m.group(1) or "wikidata.org" in text):
            uri = WD + m.group(1)
            return uri if self.sparql.ask(f"ASK {{ <{uri}> ?p ?o }}") else None
        for prefix in ("http://dbpedia.org/resource/", "https://dbpedia.org/page/",
                       "https://en.wikipedia.org/wiki/"):
            if text.startswith(prefix):
                text = text[len(prefix):]
        title = text.replace("_", " ").strip()
        if not title:
            raise ValueError("Empty entity name.")
        rows = self._select(f"""
SELECT ?item WHERE {{
  ?article schema:about ?item ; schema:isPartOf <https://en.wikipedia.org/> ;
           schema:name "{sparql_string(title)}"@en .
}} LIMIT 1""")
        return check_iri(rows[0]["item"]["value"]) if rows else None

    # ------------------------------------------------------------ extraction

    def outgoing(self, subjects, per_node):
        rows = []
        for chunk in chunks(subjects, 20):
            values = " ".join(f"<{s}>" for s in chunk)
            result = self._select(f"""
SELECT ?s ?p ?o WHERE {{
  VALUES ?s {{ {values} }}
  ?s ?p ?o .
  ?prop wikibase:directClaim ?p ; wikibase:propertyType ?type .
  FILTER(?type IN ({KEPT_TYPES}))
  {_not_in("?p", EXCLUDED)}
  FILTER( (isIRI(?o) && STRSTARTS(STR(?o), "{WD}Q"))
       || (isLiteral(?o) && (lang(?o) = "" || langMatches(lang(?o), "en"))) )
}} LIMIT {min(10000, per_node * len(chunk) * 3)}""")
            by_subject = defaultdict(list)
            for r in result:
                by_subject[r["s"]["value"]].append((r["s"]["value"], r["p"]["value"], r["o"]))
            for s in chunk:
                ordered = sorted(by_subject.get(s, []), key=lambda t: (t[1], t[2]["value"]))
                rows.extend(round_robin(ordered, per_node))
        return rows

    def incoming(self, seed, limit):
        """Incoming edges spread over relations: count subjects per relation, then take
        an equal share from each, most notable (most sitelinks) first."""
        counts = self._select(f"""
SELECT ?p (COUNT(?s) AS ?n) WHERE {{
  ?s ?p <{seed}> .
  ?prop wikibase:directClaim ?p ; wikibase:propertyType wikibase:WikibaseItem .
  {_not_in("?p", EXCLUDED_IN)}
}} GROUP BY ?p ORDER BY DESC(?n) LIMIT 25""")
        preds = [r["p"]["value"] for r in counts]
        if not preds:
            return []
        share = max(3, limit // len(preds))
        rows = []
        for p in preds:
            result = self._select(f"""
SELECT ?s WHERE {{
  ?s <{p}> <{seed}> .
  FILTER(STRSTARTS(STR(?s), "{WD}Q"))
  OPTIONAL {{ ?s wikibase:sitelinks ?sl }}
}} ORDER BY DESC(?sl) ?s LIMIT {share}""")
            rows.extend((r["s"]["value"], p, {"type": "uri", "value": seed}) for r in result)
        return rows[:limit]

    def labels(self, uris):
        out = {}
        for chunk in chunks([u for u in uris if u.startswith(WD)], 150):
            values = " ".join(f"<{u}>" for u in chunk)
            for r in self._select(
                f'SELECT ?s ?l WHERE {{ VALUES ?s {{ {values} }} ?s rdfs:label ?l FILTER(lang(?l) = "en") }}'
            ):
                out.setdefault(r["s"]["value"], r["l"]["value"])
        return out

    def predicate_labels(self, preds):
        out = {}
        for chunk in chunks([p for p in preds if p.startswith(WDT)], 150):
            values = " ".join(f"<{p}>" for p in chunk)
            for r in self._select(
                f"SELECT ?p ?l WHERE {{ VALUES ?p {{ {values} }} ?prop wikibase:directClaim ?p ; "
                f'rdfs:label ?l FILTER(lang(?l) = "en") }}'
            ):
                out.setdefault(r["p"]["value"], r["l"]["value"])
        return out

    # ------------------------------------------------------------ ontology

    def ontology(self, triples):
        preds = sorted({t["p"] for t in triples})
        subprop = defaultdict(list)
        if preds:
            values = " ".join(f"<{p}>" for p in preds)
            for r in self._select(f"""
SELECT ?p ?sup WHERE {{
  VALUES ?p {{ {values} }}
  ?prop wikibase:directClaim ?p ; wdt:P1647+ ?supProp .
  ?supProp wikibase:directClaim ?sup .
}}"""):
                subprop[r["p"]["value"]].append(r["sup"]["value"])

        # subclass closure, two levels up from classes used with P31 in the selection
        subclass: dict[str, list] = {}
        level = sorted({t["o"] for t in triples if t["p"] == WDT + "P31" and t["o"].startswith(WD)})
        for _ in range(2):
            if not level:
                break
            values = " ".join(f"<{c}>" for c in level)
            found = defaultdict(list)
            for r in self._select(f"SELECT ?c ?sup WHERE {{ VALUES ?c {{ {values} }} ?c wdt:P279 ?sup }}"):
                found[r["c"]["value"]].append(r["sup"]["value"])
            subclass.update(found)
            level = sorted({s for v in found.values() for s in v} - set(subclass))
        classes = set(subclass) | {s for v in subclass.values() for s in v}
        return {
            "type_pred": WDT + "P31", "type_label": "instance of",
            "subprop": dict(subprop), "domain": {}, "range": {},
            "subclass": subclass, "preserving": PRESERVING, "containment": CONTAINMENT,
            "stoplist": CLASS_STOPLIST, "labels": self.labels(sorted(classes)),
        }

    # ------------------------------------------------------------ oracle

    def oracle_direct(self, s, o):
        rows = self._select(f"""
SELECT ?s ?p ?o WHERE {{
  {{ <{s}> ?p <{o}> . BIND(<{s}> AS ?s) BIND(<{o}> AS ?o) }}
  UNION {{ <{o}> ?p <{s}> . BIND(<{o}> AS ?s) BIND(<{s}> AS ?o) }}
  {_wdt_filter()}
}} LIMIT 5""")
        return [(r["s"]["value"], r["p"]["value"], r["o"]["value"]) for r in rows]

    def oracle_path(self, s, o):
        rows = self._select(f"""
SELECT ?p1 ?m ?p2 WHERE {{
  <{s}> ?p1 ?m . ?m ?p2 <{o}> .
  FILTER(isIRI(?m) && ?m != <{s}> && ?m != <{o}>)
  {_wdt_filter("?p1")} {_wdt_filter("?p2")}
}} LIMIT 3""")
        return [[(s, r["p1"]["value"], r["m"]["value"]), (r["m"]["value"], r["p2"]["value"], o)]
                for r in rows]

    def oracle_literal(self, s, literal):
        lit = sparql_string(literal, 100)
        rows = self._select(f"""
SELECT ?p ?v WHERE {{
  <{s}> ?p ?v . FILTER(isLiteral(?v))
  {_wdt_filter()}
  FILTER(CONTAINS(LCASE(STR(?v)), LCASE("{lit}")))
}} LIMIT 5""")
        return [(s, r["p"]["value"], r["v"]["value"]) for r in rows]

    def popularity(self, uri):
        rows = self._select(f"SELECT ?n WHERE {{ <{uri}> wikibase:sitelinks ?n }}")
        return {"measure": "Wikipedia sitelinks", "value": int(rows[0]["n"]["value"])} if rows else None
