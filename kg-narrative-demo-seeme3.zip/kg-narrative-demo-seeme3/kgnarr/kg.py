"""Source-agnostic candidate subgraph extraction.

Policy (documented because it shapes every downstream result):
  * each source decides which predicates and objects are admissible (see sources/)
  * hop 1 takes outgoing edges of the seed plus up to `in_limit` incoming edges;
    deeper hops follow outgoing edges only (incoming edges of hubs explode)
  * at most `per_node` outgoing triples per expanded node, and at most
    `expand_cap` nodes expanded per hop, preferring nodes reached by more triples
"""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from urllib.parse import unquote

from .config import SETTINGS

# ---------------------------------------------------------------- naming helpers


def local_name(uri: str) -> str:
    return unquote(uri.rstrip("/").rsplit("/", 1)[-1]).rsplit("#", 1)[-1]


def humanize_resource(uri: str) -> str:
    return local_name(uri).replace("_", " ")


def humanize_predicate(uri: str) -> str:
    return re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", local_name(uri)).lower()


def is_literal_id(node_id: str) -> bool:
    return node_id.startswith("lit:")


def literal_node(s: str, p: str, term: dict, hop: int) -> dict:
    value = term["value"]
    datatype = term.get("datatype", "")
    key = hashlib.sha1(f"{s}|{p}|{value}".encode("utf-8")).hexdigest()[:12]
    label = value if len(value) <= 80 else value[:77] + "..."
    return {"id": f"lit:{key}", "kind": "literal", "hop": hop, "label": label, "value": value,
            "datatype": local_name(datatype) if datatype else ""}


# ---------------------------------------------------------------- extraction


def build_candidate(source, seed: str, hops: int) -> dict:
    s_ = SETTINGS
    nodes: dict[str, dict] = {seed: {"id": seed, "kind": "seed", "hop": 0}}
    triples: list[dict] = []
    seen: set = set()
    frontier = [seed]

    for hop in range(1, hops + 1):
        if not frontier:
            break
        rows = source.outgoing(frontier, s_.per_node)
        if hop == 1:
            rows += source.incoming(seed, s_.in_limit)
        new_counts: Counter = Counter()
        for s, p, term in rows:
            if len(triples) >= s_.max_triples:
                break
            key = (s, p, term["value"], term.get("datatype"), term.get("xml:lang"))
            if key in seen:
                continue
            seen.add(key)
            if term["type"] == "uri":
                o = term["value"]
                for n in (s, o):
                    if n not in nodes:
                        nodes[n] = {"id": n, "kind": "entity", "hop": hop}
                    if nodes[n]["hop"] == hop:
                        new_counts[n] += 1
            else:
                lit = literal_node(s, p, term, hop)
                nodes[lit["id"]] = lit
                o = lit["id"]
            triples.append({"s": s, "p": p, "o": o, "hop": hop})
        frontier = [n for n, _ in sorted(new_counts.items(), key=lambda kv: (-kv[1], kv[0]))]
        frontier = frontier[: s_.expand_cap]

    entity_ids = [n for n, d in nodes.items() if d["kind"] != "literal"]
    labels = source.labels(entity_ids)
    for n in entity_ids:
        nodes[n]["label"] = labels.get(n) or humanize_resource(n)
    return finish(source, seed, hops, nodes, triples)


def finish(source, seed, hops, nodes, triples) -> dict:
    plabels = source.predicate_labels(sorted({t["p"] for t in triples}))
    for i, t in enumerate(triples):
        t["id"] = f"c{i}"
        t["p_label"] = plabels.get(t["p"]) or humanize_predicate(t["p"])
    return {"seed": seed, "hops": hops, "source": source.name, "nodes": nodes, "triples": triples}


def get_candidate(source, seed: str, hops: int) -> dict:
    """Candidate neighbourhood for a resolved seed URI (cached on disk)."""
    if getattr(source, "fixture", False):
        return source.fixture_candidate(seed, hops)
    cache = SETTINGS.data_dir / "candidates"
    cache.mkdir(parents=True, exist_ok=True)
    s_ = SETTINGS
    key = hashlib.sha1(
        f"v2|{source.name}|{seed}|{hops}|{s_.per_node}|{s_.expand_cap}|{s_.in_limit}|{s_.max_triples}".encode()
    ).hexdigest()
    path = cache / f"{key}.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    cand = build_candidate(source, seed, hops)
    path.write_text(json.dumps(cand), encoding="utf-8")
    return cand
