"""Budgeted subgraph selectors.

Every selector returns exactly `budget` triples (or fewer if the candidate is
smaller), so selectors are compared at equal input size.

Node scores feed triple scores as min(score(s), score(o)): a triple is worth
what its weaker endpoint is worth, which is usually the endpoint it adds.

`connected-*` selectors grow outward from the seed and only ever add triples
touching already-selected nodes, so the result is always connected. Top-k
selectors can return disconnected fragments; the diagnostics report this.
"""
from __future__ import annotations

import heapq
import random
from collections import Counter, defaultdict, deque

from .config import SETTINGS
from .kg import humanize_resource

LITERAL_DISCOUNT = 0.9  # wiki2vec: a literal inherits its subject's similarity x this


# ---------------------------------------------------------------- node scores

def _adjacency(cand):
    adj = defaultdict(list)
    for t in cand["triples"]:
        adj[t["s"]].append(t["o"])
        adj[t["o"]].append(t["s"])
    return adj


def ppr_scores(cand, alpha: float = 0.85, iters: int = 50) -> dict[str, float]:
    """Personalized PageRank from the seed (power iteration, undirected)."""
    adj = _adjacency(cand)
    seed = cand["seed"]
    if seed not in adj:
        return {}
    rank = {n: 0.0 for n in adj}
    rank[seed] = 1.0
    for _ in range(iters):
        nxt = dict.fromkeys(adj, 0.0)
        for n, v in rank.items():
            if v:
                share = alpha * v / len(adj[n])
                for m in adj[n]:
                    nxt[m] += share
        nxt[seed] += 1 - alpha
        rank = nxt
    return rank


def degree_scores(cand) -> dict[str, float]:
    return {n: float(len(nb)) for n, nb in _adjacency(cand).items()}


_w2v_model = None


def _wiki2vec():
    global _w2v_model
    if _w2v_model is None:
        if not SETTINGS.wiki2vec_path:
            raise RuntimeError("Set KGN_WIKI2VEC to a Wikipedia2Vec model file to use this selector.")
        from wikipedia2vec import Wikipedia2Vec  # optional dependency
        _w2v_model = Wikipedia2Vec.load(SETTINGS.wiki2vec_path)
    return _w2v_model


def wiki2vec_scores(cand) -> tuple[dict[str, float], dict]:
    import numpy as np

    model = _wiki2vec()

    def vec(uri):
        try:
            return model.get_entity_vector(humanize_resource(uri))
        except KeyError:
            return None

    seed_vec = vec(cand["seed"])
    if seed_vec is None:
        raise RuntimeError("The seed entity is not in the Wikipedia2Vec vocabulary.")
    seed_norm = float(np.linalg.norm(seed_vec))
    scores: dict[str, float] = {cand["seed"]: 1.0}
    oov = 0
    entities = [n for n, d in cand["nodes"].items() if d["kind"] == "entity"]
    for n in entities:
        v = vec(n)
        if v is None:
            oov += 1
            scores[n] = 0.0
        else:
            scores[n] = float(np.dot(seed_vec, v) / (seed_norm * float(np.linalg.norm(v)) or 1.0))
    for t in cand["triples"]:  # literal policy: inherit subject similarity, discounted
        if cand["nodes"][t["o"]]["kind"] == "literal":
            scores[t["o"]] = scores.get(t["s"], 0.0) * LITERAL_DISCOUNT
    return scores, {"oov_entities": oov, "entities": len(entities)}


# ---------------------------------------------------------------- selection strategies
#
# Relation cap: at most `cap` triples may share a predicate on the same node
# (e.g. at most 3 "X birth place Athens" triples). Without it, hub entities are
# dominated by one incoming relation. If the candidate runs out of admissible
# triples, the cap is relaxed so every selector still returns `budget` triples.


class _Cap:
    def __init__(self, cap):
        self.cap = cap
        self.counts = Counter()

    def ok(self, t):
        return self.cap is None or (self.counts[(t["p"], "s", t["s"])] < self.cap
                                    and self.counts[(t["p"], "o", t["o"])] < self.cap)

    def take(self, t):
        self.counts[(t["p"], "s", t["s"])] += 1
        self.counts[(t["p"], "o", t["o"])] += 1


def _triple_score(t, node_scores):
    return min(node_scores.get(t["s"], 0.0), node_scores.get(t["o"], 0.0))


def _take_in_order(ordered, budget, cap):
    capper, chosen, skipped = _Cap(cap), [], []
    for t in ordered:
        if len(chosen) >= budget:
            break
        if capper.ok(t):
            chosen.append(t)
            capper.take(t)
        else:
            skipped.append(t)
    return chosen + skipped[: budget - len(chosen)]


def _top_k(cand, budget, node_scores, cap):
    ranked = sorted(cand["triples"], key=lambda t: (-_triple_score(t, node_scores), t["id"]))
    return _take_in_order(ranked, budget, cap)


def _connected_greedy(cand, budget, node_scores, cap):
    """Grow from the seed, always adding the best admissible triple on the frontier."""
    by_node = defaultdict(list)
    for t in cand["triples"]:
        by_node[t["s"]].append(t)
        by_node[t["o"]].append(t)
    capper = _Cap(cap)
    chosen, chosen_ids, reached, deferred = [], set(), {cand["seed"]}, []
    heap = [(-_triple_score(t, node_scores), t["id"], t) for t in by_node[cand["seed"]]]
    heapq.heapify(heap)
    while len(chosen) < budget:
        if not heap:
            if not deferred or capper.cap is None:
                break
            capper.cap = None  # frontier exhausted under the cap: relax it
            heap = deferred
            heapq.heapify(heap)
            deferred = []
        item = heapq.heappop(heap)
        _, tid, t = item
        if tid in chosen_ids:
            continue
        if not capper.ok(t):
            deferred.append(item)
            continue
        chosen.append(t)
        chosen_ids.add(tid)
        capper.take(t)
        for n in (t["s"], t["o"]):
            if n not in reached:
                reached.add(n)
                for u in by_node[n]:
                    if u["id"] not in chosen_ids:
                        heapq.heappush(heap, (-_triple_score(u, node_scores), u["id"], u))
    return chosen


def select_random(cand, budget, cap, rng_seed=13):
    rng = random.Random(rng_seed)
    triples = list(cand["triples"])
    rng.shuffle(triples)
    return _take_in_order(triples, budget, cap), {}


def select_degree(cand, budget, cap):
    return _top_k(cand, budget, degree_scores(cand), cap), {}


def select_ppr(cand, budget, cap):
    return _top_k(cand, budget, ppr_scores(cand), cap), {}


def select_wiki2vec(cand, budget, cap):
    scores, extra = wiki2vec_scores(cand)
    return _top_k(cand, budget, scores, cap), extra


def select_connected_ppr(cand, budget, cap):
    return _connected_greedy(cand, budget, ppr_scores(cand), cap), {}


def select_connected_wiki2vec(cand, budget, cap):
    scores, extra = wiki2vec_scores(cand)
    return _connected_greedy(cand, budget, scores, cap), extra


SELECTORS = {
    "random": ("Random", select_random, False),
    "degree": ("Degree (hubs first)", select_degree, False),
    "ppr": ("Personalized PageRank", select_ppr, False),
    "connected-ppr": ("Connected growth, PageRank prizes", select_connected_ppr, False),
    "wiki2vec": ("Wikipedia2Vec similarity", select_wiki2vec, True),
    "connected-wiki2vec": ("Connected growth, Wikipedia2Vec prizes", select_connected_wiki2vec, True),
}


def available_selectors() -> list[dict]:
    return [
        {"id": key, "label": label}
        for key, (label, _, needs_w2v) in SELECTORS.items()
        if not needs_w2v or SETTINGS.wiki2vec_path
    ]


# ---------------------------------------------------------------- diagnostics

def diagnostics(cand, chosen: list[dict]) -> dict:
    n = len(chosen)
    if n == 0:
        return {"triples": 0}
    adj = defaultdict(set)
    for t in chosen:
        adj[t["s"]].add(t["o"])
        adj[t["o"]].add(t["s"])
    seen, queue = {cand["seed"]}, deque([cand["seed"]])
    while queue:
        for m in adj[queue.popleft()]:
            if m not in seen:
                seen.add(m)
                queue.append(m)
    in_component = sum(1 for t in chosen if t["s"] in seen and t["o"] in seen)
    literals = sum(1 for t in chosen if cand["nodes"][t["o"]]["kind"] == "literal")
    hops = Counter(t["hop"] for t in chosen)
    top_pred, top_count = Counter(t["p"] for t in chosen).most_common(1)[0]
    return {
        "triples": n,
        "candidate_triples": len(cand["triples"]),
        "connected_fraction": round(in_component / n, 3),
        "literal_fraction": round(literals / n, 3),
        "relation_diversity": round(len({t["p"] for t in chosen}) / n, 3),
        "top_relation_share": round(top_count / n, 3),
        "top_relation": next((t["p_label"] for t in chosen if t["p"] == top_pred), top_pred),
        "hop_counts": {str(h): hops[h] for h in sorted(hops)},
    }


def select(cand, selector: str, budget: int, per_relation: int | None = None) -> tuple[list[dict], dict]:
    """per_relation: at most this many triples sharing a predicate on one node (None = no cap)."""
    if selector not in SELECTORS:
        raise ValueError(f"Unknown selector: {selector}")
    _, fn, _ = SELECTORS[selector]
    chosen, extra = fn(cand, budget, per_relation)
    diag = diagnostics(cand, chosen)
    diag.update(extra)
    return chosen, diag


__all__ = ["select", "available_selectors", "SELECTORS", "ppr_scores"]
