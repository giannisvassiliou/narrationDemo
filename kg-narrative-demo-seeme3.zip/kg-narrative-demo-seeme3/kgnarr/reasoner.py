"""Deterministic closure of a selected subgraph.

Rules (names appear in the UI and in saved runs):
  subproperty   (x p y), p subPropertyOf q            => (x q y)        RDFS rule rdfs7
  domain        (x p y), p domain C                   => (x type C)     RDFS rule rdfs2
  range         (x p y), p range C, y not a literal   => (y type C)     RDFS rule rdfs3
  subclass      (x type C), C subClassOf D            => (x type D)     RDFS rule rdfs9
  containment   (x p y), (y c z), c a containment relation:
                  p a place-of relation (born in, died in, ...)  => (x p z)
                  p itself a containment relation                => (x located-in z)

The containment rule is a domain rule, not RDFS; its predicate lists are
declared per source. Derived triples are given to the verifier only, never to
the writer. Wikidata supplies P1647 (subproperty) and P279 (subclass); it has
no RDFS domain/range, so those rules fire only on DBpedia.
"""
from __future__ import annotations

from collections import defaultdict

from .kg import humanize_resource, is_literal_id

LOCATED_IN = "rule:locatedIn"
MAX_DERIVED = 300


def closure(triples: list[dict], node_labels: dict[str, str], axioms: dict) -> list[dict]:
    type_pred = axioms["type_pred"]
    stop = axioms.get("stoplist", set())
    preserving = axioms.get("preserving", set())
    containment = set(axioms.get("containment", set())) | {LOCATED_IN}

    facts: dict[tuple, str] = {(t["s"], t["p"], t["o"]): t["tid"] for t in triples}
    derived: list[dict] = []

    def add(s, p, o, rule, sources) -> bool:
        key = (s, p, o)
        if key in facts or s == o or o in stop or len(derived) >= MAX_DERIVED:
            return False
        did = f"D{len(derived) + 1}"
        facts[key] = did
        derived.append({"did": did, "s": s, "p": p, "o": o, "rule": rule, "from": sources})
        return True

    for _ in range(8):  # rounds to fixpoint; chains in a 2-3 hop subgraph are short
        changed = False
        by_subject = defaultdict(list)
        for (s, p, o), fid in facts.items():
            by_subject[s].append((p, o, fid))
        for (s, p, o), fid in list(facts.items()):
            for q in axioms.get("subprop", {}).get(p, []):
                changed |= add(s, q, o, "subproperty", [fid])
            for c in axioms.get("domain", {}).get(p, []):
                changed |= add(s, type_pred, c, "domain", [fid])
            if not is_literal_id(o):
                for c in axioms.get("range", {}).get(p, []):
                    changed |= add(o, type_pred, c, "range", [fid])
            if p == type_pred:
                for d in axioms.get("subclass", {}).get(o, []):
                    changed |= add(s, type_pred, d, "subclass", [fid])
            if (p in preserving or p in containment) and not is_literal_id(o):
                for p2, z, fid2 in by_subject.get(o, []):
                    if p2 in containment and not is_literal_id(z):
                        new_p = p if p in preserving else LOCATED_IN
                        changed |= add(s, new_p, z, "containment", [fid, fid2])
        if not changed:
            break

    class_labels = axioms.get("labels", {})
    for d in derived:
        d["s_label"] = node_labels.get(d["s"]) or humanize_resource(d["s"])
        d["o_label"] = node_labels.get(d["o"]) or class_labels.get(d["o"]) or humanize_resource(d["o"])
    return derived


def expand_to_triples(ids: list[str], derived_by_id: dict[str, dict]) -> list[str]:
    """Resolve evidence IDs (T.. and D..) to the input triples they rest on."""
    out, stack, seen = [], list(ids), set()
    while stack:
        i = stack.pop()
        if i in seen:
            continue
        seen.add(i)
        if i.startswith("D") and i in derived_by_id:
            stack.extend(derived_by_id[i]["from"])
        elif i.startswith("T"):
            out.append(i)
    return sorted(set(out), key=lambda x: int(x[1:]))
