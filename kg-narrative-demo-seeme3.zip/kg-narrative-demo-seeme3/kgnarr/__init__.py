"""KG narrative audit demo: k-hop subgraph -> Claude narrative -> claim-level audit."""
