"""Runtime configuration, read from environment variables."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _flag(name: str) -> bool:
    return os.environ.get(name, "0").strip().lower() in {"1", "true", "yes"}


def _temperature() -> float | None:
    # Unset by default: some models reject the parameter.
    raw = os.environ.get("KGN_TEMPERATURE", "").strip()
    return None if raw == "" else float(raw)


@dataclass(frozen=True)
class Settings:
    dbpedia_endpoint: str = os.environ.get(
        "KGN_DBPEDIA_ENDPOINT", os.environ.get("KGN_ENDPOINT", "https://dbpedia.org/sparql"))
    wikidata_endpoint: str = os.environ.get("KGN_WIKIDATA_ENDPOINT", "https://query.wikidata.org/sparql")
    model: str = os.environ.get("KGN_MODEL", "claude-sonnet-5")
    verifier_model: str = os.environ.get(
        "KGN_VERIFIER_MODEL", os.environ.get("KGN_MODEL", "claude-sonnet-5")
    )
    temperature: float | None = _temperature()
    mock_llm: bool = _flag("KGN_MOCK_LLM")     # fake LLM output, for UI work without an API key
    offline: bool = _flag("KGN_OFFLINE")       # use fixtures/ instead of the live endpoint
    wiki2vec_path: str | None = os.environ.get("KGN_WIKI2VEC") or None
    data_dir: Path = Path(os.environ.get("KGN_DATA", str(ROOT / "data")))

    # Full-graph lookups: per-query timeout (s), parallel workers, total time budget (s)
    oracle_timeout: int = int(os.environ.get("KGN_ORACLE_TIMEOUT", "20"))
    oracle_workers: int = int(os.environ.get("KGN_ORACLE_WORKERS", "6"))
    oracle_budget: int = int(os.environ.get("KGN_ORACLE_BUDGET", "90"))

    # Candidate extraction limits (KG neighbourhoods explode quickly)
    per_node: int = int(os.environ.get("KGN_PER_NODE", "60"))
    expand_cap: int = int(os.environ.get("KGN_EXPAND_CAP", "40"))
    in_limit: int = int(os.environ.get("KGN_IN_LIMIT", "150"))
    max_triples: int = int(os.environ.get("KGN_MAX_TRIPLES", "3000"))


SETTINGS = Settings()

DEFAULT_KEY_FILE = ROOT / "anthropic_key.txt"
_cli_key: str | None = None


def set_api_key(key: str | None) -> None:
    """Key given on the command line; takes precedence over everything else."""
    global _cli_key
    _cli_key = key.strip() if key and key.strip() else None


def api_key() -> str | None:
    """API key, in order: command line, ANTHROPIC_API_KEY, KGN_API_KEY_FILE,
    anthropic_key.txt in the project folder. Key files contain only the key."""
    if _cli_key:
        return _cli_key
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if key:
        return key
    path = Path(os.environ.get("KGN_API_KEY_FILE", str(DEFAULT_KEY_FILE))).expanduser()
    if path.is_file():
        key = path.read_text(encoding="utf-8").strip()
        return key or None
    return None
