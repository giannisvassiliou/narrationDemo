"""Minimal SPARQL client: POST, retries with backoff, on-disk result cache.

The cache matters for demos: every query result is stored, so a seed that
worked once keeps working when the public endpoint is slow or down.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from contextlib import contextmanager
from pathlib import Path

import requests

# Wikimedia asks for a User-Agent with contact details; generic agents get blocked.
# Set KGN_USER_AGENT to something like "kg-narrative-demo/0.2 (you@uni.gr)".
USER_AGENT = os.environ.get(
    "KGN_USER_AGENT",
    "kg-narrative-demo/0.2 (research prototype; https://github.com/; python-requests)",
)
RETRYABLE = {429, 500, 502, 503, 504}
_local = threading.local()


@contextmanager
def fast_lookups(timeout: int, retries: int = 1):
    """Within this block (in this thread), queries use a short timeout and few retries.
    Used for the full-graph lookups, where one slow query must not stall the whole audit."""
    old = getattr(_local, "limits", None)
    _local.limits = (timeout, retries)
    try:
        yield
    finally:
        _local.limits = old


class SparqlError(RuntimeError):
    pass


class _Permanent(SparqlError):
    """An answer that retrying will not fix (e.g. 400/403 or a non-JSON body)."""


class Sparql:
    def __init__(self, endpoint: str, cache_dir: Path, timeout: int = 60, retries: int = 3,
                 send_format: bool = True):
        self.endpoint = endpoint
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.timeout = timeout
        self.retries = retries
        # Virtuoso (DBpedia) honours format=...; Wikidata's endpoint uses the Accept header
        # and can answer in XML when given a format value it does not recognise.
        self.send_format = send_format

    def _request(self, query: str):
        data = {"query": query}
        if self.send_format:
            data["format"] = "application/sparql-results+json"
        timeout = (getattr(_local, "limits", None) or (self.timeout, None))[0]
        resp = requests.post(
            self.endpoint, data=data, timeout=timeout,
            headers={"Accept": "application/sparql-results+json", "User-Agent": USER_AGENT},
        )
        snippet = " ".join(resp.text[:300].split())
        if resp.status_code in RETRYABLE:
            raise SparqlError(f"HTTP {resp.status_code} from {self.endpoint}: {snippet}")
        if resp.status_code >= 400:
            hint = " (Wikimedia may be rejecting the User-Agent; set KGN_USER_AGENT with a contact e-mail)" \
                if resp.status_code == 403 else ""
            raise _Permanent(f"HTTP {resp.status_code} from {self.endpoint}{hint}: {snippet}")
        try:
            data = resp.json()
        except ValueError:
            ctype = resp.headers.get("Content-Type", "unknown")
            raise _Permanent(f"{self.endpoint} answered with {ctype}, not JSON: {snippet or '(empty body)'}")
        try:
            return data["boolean"] if "boolean" in data else data["results"]["bindings"]
        except (KeyError, TypeError):
            raise _Permanent(f"{self.endpoint} returned JSON without SPARQL results: {snippet}")

    def _run(self, query: str):
        key = hashlib.sha1((self.endpoint + "\n" + query).encode("utf-8")).hexdigest()
        path = self.cache_dir / f"{key}.json"
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))

        last: Exception | None = None
        retries = (getattr(_local, "limits", None) or (None, self.retries))[1]
        for attempt in range(retries):
            try:
                result = self._request(query)
                path.write_text(json.dumps(result), encoding="utf-8")
                return result
            except _Permanent:
                raise
            except (requests.RequestException, SparqlError) as exc:
                last = exc
                if attempt < retries - 1:
                    time.sleep(1.5 * (2 ** attempt))
        raise SparqlError(f"no answer after {retries} attempt(s): {last}")

    def select(self, query: str) -> list[dict]:
        return self._run(query)

    def ask(self, query: str) -> bool:
        return bool(self._run(query))
