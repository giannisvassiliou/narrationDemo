"""Narrative generation from a selected subgraph.

Modes
  graph_only   grounding instruction (stay inside the triples) + per-sentence citations
  plain        same triples and citations, no grounding instruction
  closed_book  no triples at all: what the model writes from memory alone

"graph_only" is deliberately not called closed-world: the closed-world
assumption makes absent facts false, whereas this mode only forbids the model
from asserting facts outside the supplied triples.
"""
from __future__ import annotations

from .config import SETTINGS
from .llm import call_tool

MODES = {
    "graph_only": "Graph-only",
    "plain": "Plain",
    "closed_book": "Closed-book",
}
MODE_HELP = {
    "graph_only": "Triples plus an instruction to assert nothing beyond them",
    "plain": "Same triples, no grounding instruction",
    "closed_book": "No triples: the model writes from memory",
}

NARRATIVE_TOOL = {
    "name": "write_narrative",
    "description": "Return the narrative as a list of sentences with supporting triple IDs.",
    "input_schema": {
        "type": "object",
        "properties": {
            "title": {"type": "string"},
            "sentences": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "text": {"type": "string"},
                        "evidence": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["text", "evidence"],
                },
            },
        },
        "required": ["title", "sentences"],
    },
}

_GRAPH_ONLY = """You turn a knowledge-graph fragment into a short, readable narrative.

Grounding rule: every factual statement must be stated by the numbered triples, or follow directly from combining them. Do not add dates, places, people, roles, works, achievements or relationships the triples do not state, even if you know them to be true. Use connective wording only where it asserts nothing new; do not imply an order in time or a cause that the triples do not state. Leave out triples that do not fit the story.

For every sentence, list the IDs of the triples that support it."""

_PLAIN = """You turn a knowledge-graph fragment into a short, readable narrative about the seed entity. For every sentence, list the IDs of the triples it uses (an empty list if none)."""

_CLOSED_BOOK = """Write a short, readable narrative about the given entity. Return an empty evidence list for every sentence."""


def serialize(triples: list[dict]) -> str:
    lines = []
    for t in triples:
        obj = t["o_label"]
        if t.get("o_kind") == "literal" and t.get("o_datatype"):
            obj = f'"{obj}" ({t["o_datatype"]})'
        lines.append(f'{t["tid"]}: {t["s_label"]} | {t["p_label"]} | {obj}')
    return "\n".join(lines)


def generate(seed_label: str, triples: list[dict], mode: str, sentences: int) -> tuple[dict, dict]:
    if mode not in MODES:
        raise ValueError(f"Unknown mode: {mode}")
    if SETTINGS.mock_llm:
        return _mock(seed_label, triples, mode, sentences), {"mock": True}

    if mode == "closed_book":
        system = _CLOSED_BOOK
        user = f"Entity: {seed_label}\n\nWrite about {sentences} sentences."
    else:
        system = _GRAPH_ONLY if mode == "graph_only" else _PLAIN
        user = (f"Seed entity: {seed_label}\n\nTriples:\n{serialize(triples)}\n\n"
                f"Write about {sentences} sentences.")
    out, usage = call_tool(SETTINGS.model, system, user, NARRATIVE_TOOL, max_tokens=4096)
    valid = {t["tid"] for t in triples}
    cleaned = []
    for s in out.get("sentences", []):
        text = str(s.get("text", "")).strip()
        if text:
            cleaned.append({"text": text, "evidence": [e for e in s.get("evidence", []) if e in valid]})
    return {"title": str(out.get("title", seed_label)), "sentences": cleaned}, usage


def _mock(seed_label, triples, mode, sentences):
    if mode == "closed_book":
        return {"title": seed_label, "sentences": [
            {"text": f"{seed_label} is widely known for work that appears nowhere in this graph.",
             "evidence": []}]}
    out = [{"text": f'{t["s_label"]} has {t["p_label"]} {t["o_label"]}.', "evidence": [t["tid"]]}
           for t in triples[:sentences]]
    out.append({"text": "These places are located in larger regions.", "evidence": []})
    out.append({"text": f"{seed_label} later won a famous prize.", "evidence": []})
    return {"title": f"A mock story about {seed_label}", "sentences": out}
