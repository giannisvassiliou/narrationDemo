"""Claim-level audit of a narrative against its input subgraph.

Step 1 (model): a verifier call splits sentences into atomic claims and labels
    each against the INPUT triples and the rule-derived triples.
Step 2 (rules): a claim the verifier grounds on at least one derived triple (D..)
    is labelled "derived": its support was computed by the reasoner, not judged.
Step 3 (graph): each unsupported claim is looked up in the FULL KG:
    direct link or 2-step path found      -> leakage   (true, but not supplied)
    looked up, not found                  -> not_in_kg (fabrication OR a KG gap)
    could not be looked up                -> unchecked
    lookup finds a supplied/derived fact  -> relabelled (the verifier was wrong)
"""
from __future__ import annotations

import logging
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, wait

from .config import SETTINGS
from .generate import serialize
from .kg import humanize_predicate, humanize_resource
from .llm import call_tool
from .reasoner import expand_to_triples
from .sparql import SparqlError, fast_lookups

log = logging.getLogger("kgnarr")

LABELS = {
    "supported": "Stated in graph",
    "derived": "Derived by rules",
    "entailed": "Judged to follow",
    "glue": "Narrative glue",
    "leakage": "Leaked from memory",
    "not_in_kg": "Not found in KG",
    "unchecked": "Unsupported, unchecked",
}
GROUNDED = ("supported", "derived", "entailed")

_NULLABLE_STR = {"type": ["string", "null"]}

CLAIMS_TOOL = {
    "name": "record_claims",
    "description": "Record every atomic claim in the narrative with its label.",
    "input_schema": {
        "type": "object",
        "properties": {
            "claims": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "sentence": {"type": "integer", "description": "0-based sentence index"},
                        "span": {"type": "string", "description": "exact substring of the sentence expressing the claim"},
                        "claim": {"type": "string", "description": "the claim as a short standalone statement"},
                        "label": {"type": "string", "enum": ["supported", "entailed", "glue", "unsupported"]},
                        "evidence": {"type": "array", "items": {"type": "string"}},
                        "kg_subject": _NULLABLE_STR,
                        "kg_object": _NULLABLE_STR,
                        "kg_literal": _NULLABLE_STR,
                    },
                    "required": ["sentence", "span", "claim", "label", "evidence"],
                },
            }
        },
        "required": ["claims"],
    },
}

_SYSTEM = """You audit a generated narrative against the knowledge-graph triples it was given. You judge only against those triples, never against what you know.

You also get derived triples (IDs starting with D), computed from the input triples by fixed rules such as subclass and containment. They count as support.

Split each sentence into atomic claims (one fact each) and label every claim:
- supported: stated by a single input triple or a single derived triple.
- entailed: follows from combining two or more triples, where no single derived triple already states it.
- glue: wording that only connects or frames, including an order in time, a cause, or an emphasis that the triples do not state ("later", "because", "notably"). Label it glue, not unsupported.
- unsupported: any other factual content (entity, relation, date, number, role, attribute) that the triples neither state nor entail.

For each claim give `span`, copied exactly from the sentence, and `evidence`, the IDs of the triples that support it. Prefer a matching D triple over reconstructing the same inference from T triples. Evidence is empty for glue and unsupported.

For unsupported claims only, give what is needed to look the fact up in the knowledge graph: `kg_subject` and, if the fact links two entities, `kg_object`, as English Wikipedia titles with underscores (e.g. Theory_of_relativity). If the fact is a value, give `kg_literal` in the shortest form likely to appear in the knowledge graph: a year, a number, or a date as YYYY-MM-DD. Use null where a field does not apply."""


# ---------------------------------------------------------------- oracle


def _fmt(source, rows):
    uris = sorted({x for r in rows for x in (r[0], r[2]) if x.startswith("http")})
    labels = source.labels(uris) if uris else {}
    plabels = source.predicate_labels(sorted({r[1] for r in rows}))

    def name(x):
        return labels.get(x) or (humanize_resource(x) if x.startswith("http") else x)

    return [f"{name(s)} | {plabels.get(p) or humanize_predicate(p)} | {name(o)}" for s, p, o in rows]


def oracle_check(claim: dict, source, known: dict) -> dict:
    """Look an unsupported claim up in the full KG. `known` maps (s, p, o) of
    input and derived triples to their IDs."""
    if source.fixture:
        return {"status": "unchecked", "reason": "not run in offline mode"}
    try:
        with fast_lookups(SETTINGS.oracle_timeout, retries=1):
            return _oracle(claim, source, known)
    except SparqlError as exc:
        return {"status": "unchecked", "reason": f"lookup failed ({exc})"}
    except ValueError:
        return {"status": "unchecked", "reason": "the claim's entities are not valid KG names"}


def _oracle(claim, source, known):
    subj = source.resolve(claim["kg_subject"]) if claim.get("kg_subject") else None
    if not subj:
        return {"status": "unchecked", "reason": "subject not found in the knowledge graph"}

    if claim.get("kg_object"):
        obj = source.resolve(claim["kg_object"])
        if not obj:
            return {"status": "unchecked", "reason": "object not found in the knowledge graph"}
        direct = source.oracle_direct(subj, obj)
        for row in direct:
            if row in known:
                status = "derived" if known[row].startswith("D") else "supported"
                return {"status": status, "found": _fmt(source, [row]), "ids": [known[row]],
                        "reason": "the fact was in the input; the verifier missed it"}
        if direct:
            return {"status": "leakage", "found": _fmt(source, direct), "how": "direct link"}
        paths = source.oracle_path(subj, obj)
        for path in paths:
            if all(step in known for step in path):
                return {"status": "entailed", "found": _fmt(source, path), "ids": [known[s] for s in path],
                        "reason": "a 2-step path in the input connects them; the verifier missed it"}
        if paths:
            return {"status": "leakage", "found": ["; ".join(_fmt(source, p)) for p in paths],
                    "how": "2-step path"}
        return {"status": "not_in_kg", "reason": "no direct link or 2-step path between the two entities"}

    if claim.get("kg_literal"):
        found = source.oracle_literal(subj, str(claim["kg_literal"]))
        in_input = [r for r in found if r in known]
        if in_input:
            return {"status": "supported", "found": _fmt(source, in_input), "ids": [known[in_input[0]]],
                    "reason": "the value was in the input; the verifier missed it"}
        if found:
            return {"status": "leakage", "found": _fmt(source, found), "how": "value"}
        return {"status": "not_in_kg", "reason": f'no value of the subject contains "{claim["kg_literal"]}"'}

    return {"status": "unchecked", "reason": "no object or value to look up"}


# ---------------------------------------------------------------- verification


def verify(narrative: dict, triples: list[dict], derived: list[dict], source, nodes: dict) -> tuple[list, dict]:
    sentences = narrative["sentences"]
    if not triples:
        derived = []  # closed-book: nothing to derive from
    if SETTINGS.mock_llm:
        raw, usage = _mock(sentences, derived), {"mock": True}
    else:
        numbered = "\n".join(f"[{i}] {s['text']}" for i, s in enumerate(sentences))
        dlines = "\n".join(
            f'{d["did"]}: {d["s_label"]} | {d["p_label"]} | {d["o_label"]}  '
            f'({d["rule"]} rule, from {", ".join(d["from"])})' for d in derived)
        user = (f"Input triples given to the writer:\n{serialize(triples) if triples else '(none)'}\n\n"
                + (f"Derived triples:\n{dlines}\n\n" if dlines else "")
                + f"Narrative sentences:\n{numbered}")
        out, usage = call_tool(SETTINGS.verifier_model, _SYSTEM, user, CLAIMS_TOOL, max_tokens=8192)
        raw = out.get("claims", [])

    derived_by_id = {d["did"]: d for d in derived}
    valid = {t["tid"] for t in triples} | set(derived_by_id)
    known = {(t["s"], t["p"], t["o"]): t["tid"] for t in triples}
    known.update({(d["s"], d["p"], d["o"]): d["did"] for d in derived})
    for t in triples:  # literal values, so value lookups can match the input
        if t["o_kind"] == "literal":
            known[(t["s"], t["p"], nodes.get(t["o"], {}).get("value", t["o_label"]))] = t["tid"]

    claims = []
    for c in raw:
        idx = c.get("sentence")
        if not isinstance(idx, int) or not 0 <= idx < len(sentences):
            continue
        claims.append({
            "index": len(claims), "sentence": idx,
            "span": str(c.get("span") or ""), "claim": str(c.get("claim") or ""),
            "verifier_label": c.get("label", "unsupported"),
            "evidence": [e for e in c.get("evidence", []) if e in valid],
            "kg_subject": c.get("kg_subject"), "kg_object": c.get("kg_object"),
            "kg_literal": c.get("kg_literal"), "oracle": None,
        })

    # Full-graph lookups run in parallel under a total time budget, so one slow
    # endpoint query cannot stall the whole audit.
    pending = [c for c in claims if c["verifier_label"] == "unsupported"]
    if pending:
        t0 = time.time()
        pool = ThreadPoolExecutor(max_workers=max(1, SETTINGS.oracle_workers))
        futures = {pool.submit(oracle_check, c, source, known): c for c in pending}
        done, not_done = wait(futures, timeout=SETTINGS.oracle_budget)
        for f in done:
            try:
                futures[f]["oracle"] = f.result()
            except Exception as exc:  # a lookup must never break the audit
                futures[f]["oracle"] = {"status": "unchecked", "reason": f"lookup error ({exc})"}
        for f in not_done:
            futures[f]["oracle"] = {"status": "unchecked",
                                    "reason": f"lookup time limit ({SETTINGS.oracle_budget} s) reached"}
        pool.shutdown(wait=False, cancel_futures=True)
        log.info("full-graph lookups: %d claims, %d timed out, %.1f s",
                 len(pending), len(not_done), time.time() - t0)

    for claim in claims:
        vlabel = claim["verifier_label"]
        if vlabel in ("supported", "entailed"):
            label = "derived" if any(e.startswith("D") for e in claim["evidence"]) else vlabel
        elif vlabel == "unsupported":
            label = claim["oracle"]["status"]
            if claim["oracle"].get("ids"):
                claim["evidence"] = claim["oracle"]["ids"]
        else:
            label = vlabel
        claim["label"] = label if label in LABELS else "unchecked"
        claim["evidence_triples"] = expand_to_triples(claim["evidence"], derived_by_id)
        cited = set(sentences[claim["sentence"]].get("evidence", []))
        claim["citation_ok"] = (set(claim["evidence_triples"]) <= cited) if claim["label"] in GROUNDED else None
    return claims, usage


def attach_segments(sentences: list[dict], claims: list[dict]) -> None:
    """Split each sentence into plain text and claim spans for highlighting."""
    for i, sent in enumerate(sentences):
        text = sent["text"]
        spans = []
        for c in (c for c in claims if c["sentence"] == i):
            c["rendered"] = False
            if not c["span"]:
                continue
            start = text.find(c["span"])
            if start < 0:
                start = text.lower().find(c["span"].lower())
            if start >= 0:
                spans.append((start, start + len(c["span"]), c))
        spans.sort(key=lambda x: (x[0], -(x[1] - x[0])))
        segments, pos = [], 0
        for start, end, c in spans:
            if start < pos:
                continue  # overlapping span: listed under the sentence instead
            if start > pos:
                segments.append({"text": text[pos:start], "claim": None})
            segments.append({"text": text[start:end], "claim": c["index"]})
            c["rendered"] = True
            pos = end
        if pos < len(text):
            segments.append({"text": text[pos:], "claim": None})
        sent["segments"] = segments


def metrics(claims: list[dict], n_triples: int) -> dict:
    counts = Counter(c["label"] for c in claims)
    factual = [c for c in claims if c["label"] != "glue"]
    grounded = [c for c in factual if c["label"] in GROUNDED]
    covered = {t for c in grounded for t in c["evidence_triples"]}

    def ratio(a, b):
        return round(a / b, 3) if b else None

    return {
        "counts": {k: counts.get(k, 0) for k in LABELS},
        "claims": len(claims),
        "grounded_precision": ratio(len(grounded), len(factual)),
        "rule_backed": ratio(counts.get("derived", 0), len(grounded)),
        "leakage_rate": ratio(counts.get("leakage", 0), len(factual)),
        "triple_coverage": ratio(len(covered), n_triples),
        "glue_share": ratio(counts.get("glue", 0), len(claims)),
    }


def _mock(sentences, derived):
    """Deterministic fake verifier output, for UI work and tests."""
    out = []
    for i, s in enumerate(sentences):
        text = s["text"].rstrip(".")
        if s["evidence"]:
            out.append({"sentence": i, "span": text, "claim": text, "label": "supported",
                        "evidence": s["evidence"]})
        elif derived and "located" in text:
            out.append({"sentence": i, "span": text, "claim": text, "label": "supported",
                        "evidence": [derived[0]["did"]]})
        else:
            out.append({"sentence": i, "span": "later", "claim": "temporal ordering", "label": "glue",
                        "evidence": []})
            out.append({"sentence": i, "span": "famous prize", "claim": text, "label": "unsupported",
                        "evidence": [], "kg_subject": "Albert_Einstein",
                        "kg_object": "Nobel_Prize_in_Physics", "kg_literal": None})
    return out
