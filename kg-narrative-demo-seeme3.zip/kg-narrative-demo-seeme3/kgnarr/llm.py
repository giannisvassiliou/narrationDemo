"""Claude calls with structured output.

Structured output is obtained by forcing a single tool call: the tool's
input_schema is the output schema, and tool_choice pins the model to it.
"""
from __future__ import annotations

from .config import SETTINGS, api_key


class LLMError(RuntimeError):
    pass


_client = None
_no_temperature: set[str] = set()  # models that rejected the parameter this session


def _anthropic():
    global _client
    if _client is None:
        import anthropic

        key = api_key()
        if not key:
            raise LLMError("No API key: set ANTHROPIC_API_KEY or put the key in anthropic_key.txt.")
        _client = anthropic.Anthropic(api_key=key)
    return _client


def call_tool(model: str, system: str, user: str, tool: dict, max_tokens: int = 4096) -> tuple[dict, dict]:
    """Return (tool_input, usage) for a forced call of `tool`."""
    kwargs = dict(
        model=model,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user}],
        tools=[tool],
        tool_choice={"type": "tool", "name": tool["name"]},
    )
    if SETTINGS.temperature is not None and model not in _no_temperature:
        kwargs["temperature"] = SETTINGS.temperature
    try:
        try:
            resp = _anthropic().messages.create(**kwargs)
        except Exception as exc:
            # Some models reject `temperature`; retry once without it.
            if "temperature" in kwargs and "temperature" in str(exc).lower():
                _no_temperature.add(model)
                kwargs.pop("temperature")
                resp = _anthropic().messages.create(**kwargs)
            else:
                raise
    except LLMError:
        raise
    except Exception as exc:  # surface API errors to the UI in one readable line
        raise LLMError(f"Claude API call failed: {exc}") from exc

    if resp.stop_reason == "max_tokens":
        raise LLMError("Claude hit max_tokens before finishing; reduce the budget or sentence count.")
    for block in resp.content:
        if block.type == "tool_use" and block.name == tool["name"]:
            usage = {"input_tokens": resp.usage.input_tokens, "output_tokens": resp.usage.output_tokens}
            return block.input, usage
    raise LLMError("Claude returned no structured output.")
