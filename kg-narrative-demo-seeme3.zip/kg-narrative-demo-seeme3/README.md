# KG narrative audit

A demo for graph-grounded narrative generation. It takes a seed entity, extracts a k-hop neighbourhood from DBpedia or Wikidata, selects a budgeted subgraph, has Claude write a narrative from it, and audits every claim. Two settings can be compared side by side on the same seed. The interface traces each claim back to its supporting triples in the graph, and lets a human correct the automatic label, producing annotation data for validating the verifier.

## Run

```bash
pip install -r requirements.txt
python app.py --key-file ~/anthropic.key     # http://127.0.0.1:5000
python app.py --api-key sk-ant-...           # works too, but the key lands in shell history
```

The key is taken from, in order: `--api-key` or `--key-file`, `ANTHROPIC_API_KEY`, the file named by `KGN_API_KEY_FILE`, and `anthropic_key.txt` in the project folder (git-ignored).

Without network or an API key: `KGN_OFFLINE=1 KGN_MOCK_LLM=1 python app.py` uses a hand-made DBpedia-style fixture and fake LLM output, for UI work only. Tests: `python -m pytest -q`.

## Before a demo session: prepare examples

Live runs take tens of seconds (SPARQL plus two model calls). Prepared examples load instantly:

```bash
python precompute.py --key-file key.txt --seeds seeds.txt --preset memory
python precompute.py --key-file key.txt --seeds seeds.txt --preset selectors
python precompute.py --key-file key.txt --seeds seeds.txt --preset memory --source wikidata
```

| Preset | Setting A | Setting B |
|---|---|---|
| `memory` | graph-only prompt | closed-book (no triples), same subgraph |
| `prompts` | graph-only prompt | plain prompt, same subgraph |
| `selectors` | PageRank top-k, graph-only | connected growth, graph-only |

Examples are stored in `data/gallery/` and listed by seed popularity (incoming Wikipedia links for DBpedia, sitelinks for Wikidata). Existing examples are skipped unless `--force`. Every SPARQL result is cached in `data/sparql-cache/`, so a prepared seed also rebuilds offline. Copy the whole `data/` folder to the demo laptop.

## Prompts

- **Graph-only**: the triples, plus an instruction to assert nothing beyond them. Deliberately not called "closed-world": the closed-world assumption makes absent facts false, whereas this only forbids asserting them.
- **Plain**: the same triples without the instruction. The gap to graph-only is the effect of the instruction.
- **Closed-book**: no triples. What the model says from memory; the ceiling for leakage.

## Audit labels

| Label | Meaning | Decided by |
|---|---|---|
| Stated in graph | one supplied triple states it | verifier |
| Derived by rules | follows from supplied triples by a fixed rule | reasoner, matched by the verifier |
| Judged to follow | follows from several triples, no rule covers it | verifier |
| Narrative glue | time order, cause or emphasis the graph does not state | verifier |
| Leaked from memory | not supplied, but in the full KG (direct link, 2-step path, or value) | full-KG lookup |
| Not found in KG | not supplied, not in the full KG: invented, or a KG gap | full-KG lookup |
| Unsupported, unchecked | not supplied, lookup could not run | |

If the full-KG lookup finds a fact that was in the input or derived from it, the verifier was wrong and the label is corrected.

## Rule reasoner

`kgnarr/reasoner.py` computes a closure of the selected subgraph before verification. Derived triples go to the verifier only, never to the writer.

- RDFS rules: subproperty (rdfs7), domain (rdfs2), range (rdfs3), subclass (rdfs9). DBpedia supplies `rdfs:subPropertyOf`, `rdfs:domain`, `rdfs:range`, `rdfs:subClassOf` from its ontology. Wikidata supplies P1647 (subproperty) and P279 (subclass, two levels up from P31 classes); it has no RDFS domain/range, so those rules fire only on DBpedia.
- Containment (a domain rule, not RDFS): for place-of relations (born in, died in, ...) followed by a containment relation (country, state, P131, ...), the place-of relation carries up the chain; containment followed by containment gives a generic "located in".

## Analysing annotations

Annotators label claims in the right-hand panel ("Save label"; every reviewed claim should be saved, including agreements). Then:

```bash
python agreement.py              # automatic vs human: kappa, confusion matrix, per-label precision/recall
python agreement.py --coarse     # grounded / glue / unsupported
python agreement.py --json report.json
```

With two annotators on the same claims, it also reports inter-annotator kappa. This is the validation number the demo paper needs.

## Configuration

| Variable | Default | Meaning |
|---|---|---|
| `KGN_MODEL` | `claude-sonnet-5` | Narrative writer |
| `KGN_VERIFIER_MODEL` | same as writer | Claim verifier; a different model family avoids self-preference bias |
| `KGN_TEMPERATURE` | unset | Omitted by default; if a model rejects it the call is retried without it |
| `KGN_DBPEDIA_ENDPOINT`, `KGN_WIKIDATA_ENDPOINT` | public endpoints | SPARQL endpoints |
| `KGN_ORACLE_TIMEOUT`, `KGN_ORACLE_WORKERS`, `KGN_ORACLE_BUDGET` | 20, 6, 90 | Full-graph lookups: seconds per query, parallel lookups, total seconds per narrative. Claims still pending when the budget runs out are labelled unchecked |
| `KGN_USER_AGENT` | generic | Sent with SPARQL requests. Wikimedia expects contact details, e.g. `kg-narrative-demo/0.2 (you@hmu.gr)` |
| `KGN_WIKI2VEC` | unset | Wikipedia2Vec model file; enables the wiki2vec selectors (`pip install wikipedia2vec numpy`) |
| `KGN_PER_NODE`, `KGN_EXPAND_CAP`, `KGN_IN_LIMIT`, `KGN_MAX_TRIPLES` | 60, 40, 150, 3000 | Candidate extraction limits |
| `KGN_DATA` | `./data` | Caches, runs, gallery, annotations |

## Variety of relations

Hub entities (cities, countries, universities) have thousands of incoming edges of one kind, such as people born there, which would otherwise fill the whole subgraph. Two mechanisms counter this:

- **Extraction.** Incoming edges are spread over relations: the extractor counts subjects per relation (top 25 relations), takes an equal share from each, and within a relation prefers notable entities (longest Wikipedia article on DBpedia, most sitelinks on Wikidata). Outgoing edges per node are taken round-robin across relations. Note that preferring notable neighbours also favours facts the model is likely to know, which matters for leakage measurements.
- **Selection.** "Per relation" (default 3; `--per-relation` in `precompute.py`) allows at most that many triples sharing a relation on the same entity, e.g. at most three "X birth place Athens" triples. Set it to 0 to switch the limit off, for example to compare against the uncapped selection. If a candidate runs out of admissible triples, the limit is relaxed so every selector still returns the requested number.

The diagnostics panel shows the most frequent relation and its share of the selection.

## Extraction policy

DBpedia: `dbo:` predicates minus Wikipedia bookkeeping. Wikidata: truthy `wdt:` statements of item, time, quantity, string and monolingual-text types (no external identifiers, URLs or media), minus bookkeeping properties; incoming authorship (P50) is skipped because scholarly articles flood hub entities. Seeds are English Wikipedia titles for both KGs, so the same seed list compares the two. Hop 1 adds up to 150 incoming edges; deeper hops follow outgoing edges, expanding at most 40 nodes per hop.

## Known limitations

- The verifier is a model: matching a claim to a derived triple, and the labels "stated" and "judged to follow", are model judgements. Only the derivation itself is deterministic. Report `agreement.py` numbers before using any automatic metric.
- The full-KG lookup checks direct links, 2-step paths in one direction, and literal substrings. Facts expressed differently are reported as "not found in KG".
- Wikidata incoming edges are capped without ordering, so the candidate set for hub entities depends on endpoint order (cached after the first run).
- No path coverage, parametric-overlap probe or renamed-entity control yet.
