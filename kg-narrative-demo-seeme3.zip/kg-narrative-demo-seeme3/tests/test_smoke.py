"""Tests that run without network or API key (offline fixture + mock LLM).

    python -m pytest -q
"""
import json
import os
import sys
import tempfile
from pathlib import Path

os.environ["KGN_OFFLINE"] = "1"
os.environ["KGN_MOCK_LLM"] = "1"
os.environ["KGN_DATA"] = tempfile.mkdtemp(prefix="kgn-test-")
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import agreement  # noqa: E402
from app import app  # noqa: E402
from kgnarr import kg, reasoner, selectors, verify  # noqa: E402
from kgnarr.sources import get_source  # noqa: E402
from kgnarr.sources.dbpedia import DBO, DBR  # noqa: E402
from kgnarr.sources.wikidata import WD, WDT, WikidataSource  # noqa: E402

SEED = DBR + "Albert_Einstein"


# ---------------------------------------------------------------- selection

def test_selectors_respect_budget_and_connectivity():
    cand = kg.get_candidate(get_source("dbpedia"), SEED, 3)
    assert len(cand["triples"]) == 33
    for name, (_, _, needs_w2v) in selectors.SELECTORS.items():
        if needs_w2v:
            continue
        chosen, diag = selectors.select(cand, name, 10)
        assert len(chosen) == 10, name
        if name.startswith("connected"):
            assert diag["connected_fraction"] == 1.0, name


def test_hop_filter():
    assert all(t["hop"] <= 1 for t in kg.get_candidate(get_source("dbpedia"), SEED, 1)["triples"])


# ---------------------------------------------------------------- reasoner

def _t(tid, s, p, o):
    return {"tid": tid, "s": DBR + s, "p": DBO + p, "o": DBR + o}


def test_reasoner_rules():
    triples = [_t("T1", "Einstein", "birthPlace", "Ulm"), _t("T2", "Ulm", "country", "Germany"),
               _t("T3", "Einstein", "doctoralAdvisor", "Kleiner"),
               _t("T4", "Ulm", "federalState", "BW"), _t("T5", "BW", "country", "Germany")]
    axioms = {"type_pred": "type", "subprop": {DBO + "doctoralAdvisor": [DBO + "advisor"]},
              "domain": {DBO + "doctoralAdvisor": [DBO + "Scientist"]},
              "range": {DBO + "doctoralAdvisor": [DBO + "Person"]},
              "subclass": {DBO + "Scientist": [DBO + "Person", DBO + "Species"]},
              "preserving": {DBO + "birthPlace"}, "containment": {DBO + "country", DBO + "federalState"},
              "stoplist": {DBO + "Species"}, "labels": {}}
    derived = reasoner.closure(triples, {}, axioms)
    facts = {(d["s"], d["p"], d["o"]): d for d in derived}
    born_de = facts[(DBR + "Einstein", DBO + "birthPlace", DBR + "Germany")]
    assert born_de["rule"] == "containment" and born_de["from"] == ["T1", "T2"]
    assert (DBR + "Einstein", DBO + "birthPlace", DBR + "BW") in facts
    assert (DBR + "Einstein", DBO + "advisor", DBR + "Kleiner") in facts          # subproperty
    assert (DBR + "Einstein", "type", DBO + "Scientist") in facts                 # domain
    assert (DBR + "Kleiner", "type", DBO + "Person") in facts                     # range
    assert (DBR + "Einstein", "type", DBO + "Person") in facts                    # subclass
    assert not any(d["o"] == DBO + "Species" for d in derived)                    # stoplist
    # containment relation followed by containment gives the generic located-in relation
    assert facts[(DBR + "Ulm", reasoner.LOCATED_IN, DBR + "Germany")]["from"] == ["T4", "T5"]
    by_id = {d["did"]: d for d in derived}
    assert reasoner.expand_to_triples([born_de["did"]], by_id) == ["T1", "T2"]


def test_reasoner_on_fixture_selection():
    client = app.test_client()
    sel = client.post("/api/subgraph", json={"source": "dbpedia", "seed": "Albert Einstein", "hops": 3,
                                              "selector": "connected-ppr", "budget": 40}).get_json()
    lines = {(d["s_label"], d["p_label"], d["o_label"]) for d in sel["derived"]}
    assert ("Albert Einstein", "birth place", "Germany") in lines
    assert ("Albert Einstein", "death place", "New Jersey") in lines   # two containment steps
    assert ("Albert Einstein", "is a", "Scientist") in lines           # domain of doctoral advisor
    assert sel["diagnostics"]["derived_triples"] == len(sel["derived"])


# ---------------------------------------------------------------- verification

def test_segments_non_overlapping():
    sents = [{"text": "Einstein was born in Ulm, in Germany.", "evidence": []}]
    claims = [{"index": 0, "sentence": 0, "span": "born in Ulm"},
              {"index": 1, "sentence": 0, "span": "in Ulm, in Germany"},
              {"index": 2, "sentence": 0, "span": "Germany"}]
    verify.attach_segments(sents, claims)
    assert "".join(s["text"] for s in sents[0]["segments"]) == sents[0]["text"]
    assert [c["rendered"] for c in claims] == [True, False, True]


class StubSource:
    fixture = False

    def __init__(self, direct=(), paths=(), literal=()):
        self._d, self._p, self._l = list(direct), list(paths), list(literal)

    def resolve(self, name):
        return DBR + name if name else None

    def oracle_direct(self, s, o): return self._d
    def oracle_path(self, s, o): return self._p
    def oracle_literal(self, s, lit): return self._l
    def labels(self, uris): return {}
    def predicate_labels(self, preds): return {}


def test_oracle_classification():
    claim = {"kg_subject": "Albert_Einstein", "kg_object": "Nobel_Prize_in_Physics", "kg_literal": None}
    row = (SEED, DBO + "award", DBR + "Nobel_Prize_in_Physics")
    assert verify.oracle_check(claim, StubSource(direct=[row]), {})["status"] == "leakage"
    assert verify.oracle_check(claim, StubSource(direct=[row]), {row: "T3"})["status"] == "supported"
    assert verify.oracle_check(claim, StubSource(direct=[row]), {row: "D2"})["status"] == "derived"
    path = [(SEED, DBO + "birthPlace", DBR + "Ulm"), (DBR + "Ulm", DBO + "country", DBR + "Nobel_Prize_in_Physics")]
    r = verify.oracle_check(claim, StubSource(paths=[path]), {})
    assert r["status"] == "leakage" and r["how"] == "2-step path"
    assert verify.oracle_check(claim, StubSource(paths=[path]), {path[0]: "T1", path[1]: "T2"})["status"] == "entailed"
    assert verify.oracle_check(claim, StubSource(), {})["status"] == "not_in_kg"
    lit_claim = {"kg_subject": "Albert_Einstein", "kg_object": None, "kg_literal": "1879"}
    assert verify.oracle_check(lit_claim, StubSource(literal=[(SEED, DBO + "birthYear", "1879")]), {})["status"] == "leakage"
    assert verify.oracle_check({"kg_subject": None}, StubSource(), {})["status"] == "unchecked"


# ---------------------------------------------------------------- API, gallery, annotation

def test_api_flow_and_gallery():
    client = app.test_client()
    cfg = client.get("/api/config").get_json()
    assert cfg["offline"] and cfg["mock"] and [m["id"] for m in cfg["modes"]] == ["graph_only", "plain", "closed_book"]
    assert "derived" in [l["id"] for l in cfg["labels"]]

    sel = client.post("/api/subgraph", json={"source": "dbpedia", "seed": "Albert Einstein", "hops": 2,
                                              "selector": "connected-ppr", "budget": 12}).get_json()
    assert len(sel["triples"]) == 12 and sel["triples"][0]["tid"] == "T1"

    run = client.post("/api/narrate", json={"selection_id": sel["selection_id"],
                                            "mode": "graph_only", "sentences": 5}).get_json()
    m = run["metrics"]
    assert m["counts"]["supported"] == 5 and m["counts"]["derived"] == 1 and m["counts"]["unchecked"] == 1
    derived_claim = next(c for c in run["claims"] if c["label"] == "derived")
    assert derived_claim["evidence_triples"] and all(t.startswith("T") for t in derived_claim["evidence_triples"])

    ok = client.post("/api/annotate", json={"run_id": run["run_id"], "claim_index": 0,
                                            "label": "entailed", "note": "t", "annotator": "gv"}).get_json()
    assert ok["human_label"] == "entailed"

    closed = client.post("/api/narrate", json={"selection_id": sel["selection_id"],
                                               "mode": "closed_book", "sentences": 3}).get_json()
    assert closed["metrics"]["triple_coverage"] is None

    import precompute
    seeds = Path(os.environ["KGN_DATA"]) / "seeds.txt"
    seeds.write_text("Albert_Einstein\nNobody_Here\n", encoding="utf-8")
    sys.argv = ["precompute.py", "--seeds", str(seeds), "--preset", "memory", "--budget", "15"]
    assert precompute.main() == 0
    items = client.get("/api/gallery").get_json()
    assert [i["id"] for i in items] == ["dbpedia-memory-Albert_Einstein"]
    entry = client.get("/api/gallery/dbpedia-memory-Albert_Einstein").get_json()
    assert [l["run"]["mode"] for l in entry["lanes"]] == ["graph_only", "closed_book"]
    assert entry["lanes"][0]["selection"]["selection_id"] == entry["lanes"][1]["selection"]["selection_id"]
    gal_run = entry["lanes"][1]["run"]
    ok = client.post("/api/annotate", json={"run_id": gal_run["run_id"], "claim_index": 0,
                                            "label": "glue", "annotator": "gv"}).get_json()
    assert ok["ok"]


def test_errors_are_json():
    client = app.test_client()
    r = client.post("/api/subgraph", json={"source": "dbpedia", "seed": "Nobody_Here", "hops": 2,
                                           "selector": "ppr", "budget": 10})
    assert r.status_code == 404 and "error" in r.get_json()
    r = client.post("/api/subgraph", json={"source": "dbpedia", "seed": "Albert_Einstein", "hops": 7,
                                           "selector": "ppr", "budget": 10})
    assert r.status_code == 400
    r = client.post("/api/subgraph", json={"source": "wikidata", "seed": "Albert_Einstein", "hops": 2,
                                           "selector": "ppr", "budget": 10})
    assert r.status_code == 400  # offline mode has no Wikidata
    assert client.get("/api/gallery/..%2Fetc").status_code in (400, 404)


# ---------------------------------------------------------------- agreement

def test_cohen_kappa():
    assert agreement.cohen_kappa(["a", "a", "b", "b"], ["a", "a", "b", "b"]) == 1.0
    k = agreement.cohen_kappa(["a", "a", "b", "b"], ["a", "b", "a", "b"])
    assert abs(k) < 1e-9
    # 20 items: 15 agree; textbook check value
    a = ["y"] * 10 + ["n"] * 10
    b = ["y"] * 8 + ["n"] * 2 + ["y"] * 3 + ["n"] * 7
    assert round(agreement.cohen_kappa(a, b), 3) == 0.5


# ---------------------------------------------------------------- Wikidata parsing (stubbed endpoint)

class StubSparql:
    def __init__(self, answers):
        self.answers, self.queries = answers, []

    def select(self, q):
        self.queries.append(q)
        for needle, rows in self.answers:
            if needle in q:
                return rows
        return []

    def ask(self, q):
        return True


def test_wikidata_source_parsing():
    src = WikidataSource()
    src._sparql = StubSparql([
        ("schema:about", [{"item": {"value": WD + "Q937"}}]),
        ("VALUES ?s", [{"s": {"value": WD + "Q937"}, "p": {"value": WDT + "P19"},
                        "o": {"type": "uri", "value": WD + "Q3012"}}]),
    ])
    assert src.resolve("Albert_Einstein") == WD + "Q937"
    assert '"Albert Einstein"@en' in src._sparql.queries[0]
    assert src.resolve("Q937") == WD + "Q937"
    rows = src.outgoing([WD + "Q937"], 10)
    assert rows == [(WD + "Q937", WDT + "P19", {"type": "uri", "value": WD + "Q3012"})]


# ---------------------------------------------------------------- relation variety

def _hub_candidate():
    """Athens-like hub: 40 people born there, plus a few other relations."""
    seed = DBR + "Athens"
    nodes = {seed: {"id": seed, "kind": "seed", "hop": 0, "label": "Athens"}}
    triples = []
    def add(s, p, o):
        for n in (s, o):
            nodes.setdefault(n, {"id": n, "kind": "entity", "hop": 1, "label": kg.local_name(n)})
        triples.append({"id": f"c{len(triples)}", "s": s, "p": DBO + p, "o": o, "hop": 1, "p_label": p})
    for i in range(40):
        add(DBR + f"Person{i}", "birthPlace", seed)
    add(seed, "country", DBR + "Greece")
    add(seed, "mayor", DBR + "Mayor")
    add(DBR + "Acropolis", "location", seed)
    add(DBR + "Univ", "city", seed)
    add(seed, "isPartOf", DBR + "Attica")
    return {"seed": seed, "nodes": nodes, "triples": triples}


def test_per_relation_cap():
    cand = _hub_candidate()
    for name in ("random", "degree", "ppr", "connected-ppr"):
        uncapped, d0 = selectors.select(cand, name, 10, None)
        capped, d1 = selectors.select(cand, name, 10, 3)
        assert len(capped) == 10, name
        # 3 births + 5 other relations = 8 admissible; the cap is relaxed to fill the budget
        born = sum(t["p"] == DBO + "birthPlace" for t in capped[:8])
        assert born <= 3, name
        assert {t["p"] for t in capped} >= {DBO + "country", DBO + "mayor", DBO + "location"}, name
        assert d1["top_relation_share"] <= d0["top_relation_share"], name


def test_round_robin_and_incoming_share():
    from kgnarr.sources.base import round_robin
    rows = [("s", "a", i) for i in range(10)] + [("s", "b", 0), ("s", "c", 0)]
    assert [r[1] for r in round_robin(rows, 5)] == ["a", "b", "c", "a", "a"]

    from kgnarr.sources.dbpedia import DBpediaSource
    src = DBpediaSource()
    src._sparql = StubSparql([
        ("GROUP BY ?p", [{"p": {"value": DBO + "birthPlace"}, "n": {"value": "5000"}},
                         {"p": {"value": DBO + "location"}, "n": {"value": "40"}}]),
        (f"<{DBO}birthPlace>", [{"s": {"value": DBR + f"P{i}"}} for i in range(3)]),
        (f"<{DBO}location>", [{"s": {"value": DBR + "Acropolis"}}]),
    ])
    rows = src.incoming(DBR + "Athens", 150)
    assert {r[1] for r in rows} == {DBO + "birthPlace", DBO + "location"}
    assert "LIMIT 75" in src._sparql.queries[1]  # equal share: 150 / 2 relations


def test_lookups_run_in_parallel_under_a_time_budget(monkeypatch):
    import time as _time
    from kgnarr import config

    class Slow(StubSource):
        def oracle_direct(self, s, o):
            _time.sleep(0.4 if "Fast" in o else 5)
            return []

    monkeypatch.setattr(verify, "SETTINGS", config.Settings(mock_llm=False, oracle_budget=1, oracle_workers=4))
    raw = [{"sentence": 0, "span": "x", "claim": f"c{i}", "label": "unsupported", "evidence": [],
            "kg_subject": "A", "kg_object": ("Fast" if i < 3 else "Slow") + str(i)} for i in range(4)]
    monkeypatch.setattr(verify, "call_tool", lambda *a, **k: ({"claims": raw}, {}))
    t0 = _time.time()
    claims, _ = verify.verify({"sentences": [{"text": "x", "evidence": []}]}, [], [], Slow(), {})
    assert _time.time() - t0 < 2.5                      # did not wait for the 5 s lookup
    assert [c["label"] for c in claims] == ["not_in_kg"] * 3 + ["unchecked"]
    assert "time limit" in claims[3]["oracle"]["reason"]
