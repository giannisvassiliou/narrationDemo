"""KG narrative audit demo: Flask server.

Run:  python app.py --api-key sk-ant-...        (then open http://127.0.0.1:5000)
      python app.py --key-file ~/anthropic.key
"""
from __future__ import annotations

import argparse
import logging
import os
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from kgnarr import pipeline
from kgnarr.config import SETTINGS, api_key, set_api_key
from kgnarr.generate import MODE_HELP, MODES
from kgnarr.llm import LLMError
from kgnarr.selectors import available_selectors
from kgnarr.sources import available_sources
from kgnarr.sparql import SparqlError
from kgnarr.verify import LABELS

app = Flask(__name__, static_folder="static", static_url_path="/static")


def _error(message: str, status: int):
    return jsonify({"error": message}), status


@app.errorhandler(ValueError)
def _bad_request(exc):
    return _error(str(exc), 400)


@app.errorhandler(KeyError)
def _not_found(exc):
    return _error(str(exc.args[0]) if exc.args else "Not found", 404)


@app.errorhandler(SparqlError)
def _sparql(exc):
    return _error(f"The knowledge graph endpoint did not answer: {exc}. Cached seeds and prepared "
                  "examples still work.", 502)


@app.errorhandler(LLMError)
def _llm(exc):
    return _error(str(exc), 502)


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/config")
def config():
    return jsonify({
        "sources": available_sources(),
        "selectors": available_selectors(),
        "modes": [{"id": k, "label": v, "help": MODE_HELP[k]} for k, v in MODES.items()],
        "labels": [{"id": k, "label": v} for k, v in LABELS.items()],
        "model": SETTINGS.model,
        "verifier_model": SETTINGS.verifier_model,
        "offline": SETTINGS.offline,
        "mock": SETTINGS.mock_llm,
    })


def _body():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ValueError("Expected a JSON object.")
    return data


@app.post("/api/subgraph")
def subgraph():
    b = _body()
    return jsonify(pipeline.build_selection(
        str(b.get("source", "dbpedia")), str(b.get("seed", "")), int(b.get("hops", 2)),
        str(b.get("selector", "connected-ppr")), int(b.get("budget", 25)),
        int(b.get("per_relation", 3))))


@app.post("/api/narrate")
def narrate():
    b = _body()
    return jsonify(pipeline.narrate(
        str(b.get("selection_id", "")), str(b.get("mode", "graph_only")), int(b.get("sentences", 8))))


@app.post("/api/annotate")
def annotate():
    b = _body()
    return jsonify(pipeline.annotate(
        str(b.get("run_id", "")), int(b.get("claim_index", -1)), str(b.get("label", "")),
        str(b.get("note", "")), str(b.get("annotator", ""))))


@app.get("/api/gallery")
def gallery():
    return jsonify(pipeline.list_gallery())


@app.get("/api/gallery/<entry_id>")
def gallery_entry(entry_id):
    return jsonify(pipeline.get_gallery(entry_id))


def main() -> None:
    parser = argparse.ArgumentParser(description="KG narrative audit demo")
    keys = parser.add_mutually_exclusive_group()
    keys.add_argument("--api-key", help="Anthropic API key (visible in shell history; --key-file is safer)")
    keys.add_argument("--key-file", type=Path, help="file containing only the Anthropic API key")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "5000")))
    args = parser.parse_args()

    if args.key_file:
        path = args.key_file.expanduser()
        if not path.is_file():
            parser.error(f"key file not found: {path}")
        set_api_key(path.read_text(encoding="utf-8"))
    elif args.api_key:
        set_api_key(args.api_key)

    if not SETTINGS.mock_llm and not api_key():
        print("Warning: no API key. Use --api-key, --key-file, anthropic_key.txt or ANTHROPIC_API_KEY "
              "(or KGN_MOCK_LLM=1 to run without one). Prepared examples still work.")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s", datefmt="%H:%M:%S")
    app.run(host=args.host, port=args.port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
