"""Agreement report for the claim labels in data/annotations.jsonl.

    python agreement.py                 # automatic label vs human, all labels
    python agreement.py --coarse        # grounded / glue / unsupported
    python agreement.py --json out.json

Reports Cohen's kappa and a confusion matrix for the automatic pipeline
against human labels, per-label precision and recall, and pairwise kappa
between annotators on claims labelled by more than one person.
Only claims a human saved count; a label the human left unchanged still
counts as agreement, so annotators should save every claim they review.
"""
from __future__ import annotations

import argparse
import itertools
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

from kgnarr.config import SETTINGS
from kgnarr.verify import LABELS

COARSE = {
    "supported": "grounded", "derived": "grounded", "entailed": "grounded",
    "glue": "glue",
    "leakage": "unsupported", "not_in_kg": "unsupported", "unchecked": "unsupported",
}


def cohen_kappa(a: list[str], b: list[str]) -> float | None:
    n = len(a)
    if n == 0:
        return None
    po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = Counter(a), Counter(b)
    pe = sum(ca[k] * cb[k] for k in set(ca) | set(cb)) / (n * n)
    return None if pe == 1 else (po - pe) / (1 - pe)


def load(path: Path) -> dict:
    """Latest label per (annotator, run, claim)."""
    latest = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        r = json.loads(line)
        latest[(r.get("annotator", "anonymous"), r["run_id"], r["claim_index"])] = r
    return latest


def confusion(auto, human, classes):
    m = defaultdict(Counter)
    for a, h in zip(auto, human):
        m[h][a] += 1
    width = max(len(c) for c in classes) + 2
    lines = ["human \\ auto".ljust(width) + "".join(c[:10].rjust(11) for c in classes)]
    for h in classes:
        lines.append(h.ljust(width) + "".join(str(m[h][a]).rjust(11) for a in classes))
    return "\n".join(lines), {h: dict(m[h]) for h in classes}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--file", type=Path, default=SETTINGS.data_dir / "annotations.jsonl")
    ap.add_argument("--coarse", action="store_true", help="collapse to grounded / glue / unsupported")
    ap.add_argument("--json", type=Path, help="also write the report as JSON")
    args = ap.parse_args()

    if not args.file.exists():
        print(f"No annotations at {args.file}", file=sys.stderr)
        return 1
    latest = load(args.file)
    mapf = (lambda x: COARSE.get(x, x)) if args.coarse else (lambda x: x)
    classes = sorted(set(COARSE.values())) if args.coarse else list(LABELS)

    records = list(latest.values())
    auto = [mapf(r["auto_label"]) for r in records]
    human = [mapf(r["human_label"]) for r in records]
    n = len(records)
    kappa = cohen_kappa(auto, human)
    raw = sum(a == h for a, h in zip(auto, human)) / n if n else None

    print(f"Annotations: {n} (claim, annotator) pairs from {len({r['annotator'] for r in records})} annotator(s)")
    if n < 100:
        print("Warning: fewer than 100 labelled claims; treat these numbers as indicative only.")
    print(f"\nAutomatic pipeline vs human ({'coarse' if args.coarse else 'full'} labels)")
    print(f"  raw agreement {raw:.3f}   Cohen's kappa {kappa:.3f}" if kappa is not None
          else f"  raw agreement {raw}")
    table, matrix = confusion(auto, human, classes)
    print("\n" + table)

    print("\nPer label (automatic label judged against human):")
    per_label = {}
    for c in classes:
        tp = sum(a == c and h == c for a, h in zip(auto, human))
        pa, ph = auto.count(c), human.count(c)
        prec = tp / pa if pa else None
        rec = tp / ph if ph else None
        per_label[c] = {"precision": prec, "recall": rec, "auto": pa, "human": ph}
        fmt = lambda v: "  n/a" if v is None else f"{v:.2f}"
        print(f"  {c:<12} precision {fmt(prec)}  recall {fmt(rec)}  (auto {pa}, human {ph})")

    by_claim = defaultdict(dict)
    for (annotator, run_id, idx), r in latest.items():
        by_claim[(run_id, idx)][annotator] = mapf(r["human_label"])
    annotators = sorted({a for d in by_claim.values() for a in d})
    pairs = {}
    for x, y in itertools.combinations(annotators, 2):
        shared = [(d[x], d[y]) for d in by_claim.values() if x in d and y in d]
        if shared:
            k = cohen_kappa([s[0] for s in shared], [s[1] for s in shared])
            pairs[f"{x} / {y}"] = {"n": len(shared), "kappa": k}
    if pairs:
        print("\nBetween annotators:")
        for name, v in pairs.items():
            print(f"  {name}: kappa {v['kappa']:.3f} on {v['n']} shared claims" if v["kappa"] is not None
                  else f"  {name}: n={v['n']}, kappa undefined")
    else:
        print("\nBetween annotators: no claim has labels from two annotators yet.")

    if args.json:
        args.json.write_text(json.dumps({
            "n": n, "coarse": args.coarse, "raw_agreement": raw, "kappa": kappa,
            "confusion": matrix, "per_label": per_label, "inter_annotator": pairs,
        }, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
