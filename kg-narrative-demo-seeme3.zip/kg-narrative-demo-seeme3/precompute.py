"""Precompute prepared examples (the gallery) so the demo does not depend on
live SPARQL or API latency at the venue.

    python precompute.py --key-file key.txt --seeds seeds.txt --preset memory
    python precompute.py --key-file key.txt --seeds seeds.txt --preset selectors --source wikidata

Presets (each prepared example shows two settings side by side):
    memory     same subgraph: graph-only prompt vs closed-book
    prompts    same subgraph: graph-only prompt vs plain prompt
    selectors  graph-only prompt: PageRank top-k vs connected growth
"""
from __future__ import annotations

import argparse
import re
import sys
import time
from pathlib import Path

from kgnarr import pipeline
from kgnarr.config import SETTINGS, api_key, set_api_key
from kgnarr.llm import LLMError
from kgnarr.sparql import SparqlError

PRESETS = {
    "memory": [("A", None, "graph_only"), ("B", None, "closed_book")],
    "prompts": [("A", None, "graph_only"), ("B", None, "plain")],
    "selectors": [("A", "ppr", "graph_only"), ("B", "connected-ppr", "graph_only")],
}


def read_seeds(path: Path) -> list[str]:
    seeds = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip()
        if line:
            seeds.append(line)
    return seeds


def slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "-", text).strip("-")[:60] or "seed"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seeds", type=Path, default=Path("seeds.txt"))
    ap.add_argument("--source", default="dbpedia", choices=["dbpedia", "wikidata"])
    ap.add_argument("--preset", default="memory", choices=sorted(PRESETS))
    ap.add_argument("--selector", default="connected-ppr", help="selector for presets that share one subgraph")
    ap.add_argument("--hops", type=int, default=2)
    ap.add_argument("--budget", type=int, default=25)
    ap.add_argument("--sentences", type=int, default=8)
    ap.add_argument("--per-relation", type=int, default=3,
                    help="at most this many triples sharing a relation on one node (0 = no cap)")
    ap.add_argument("--force", action="store_true", help="recompute examples that already exist")
    keys = ap.add_mutually_exclusive_group()
    keys.add_argument("--api-key")
    keys.add_argument("--key-file", type=Path)
    args = ap.parse_args()

    if args.key_file:
        set_api_key(args.key_file.expanduser().read_text(encoding="utf-8"))
    elif args.api_key:
        set_api_key(args.api_key)
    if not SETTINGS.mock_llm and not api_key():
        ap.error("no API key (use --api-key or --key-file)")

    existing = {e["id"] for e in pipeline.list_gallery()}
    done, failed = 0, []
    for seed in read_seeds(args.seeds):
        entry_id = f"{args.source}-{args.preset}-{slug(seed)}"
        if entry_id in existing and not args.force:
            print(f"skip  {seed} (exists)")
            continue
        t0 = time.time()
        try:
            lanes, shared = [], None
            for key, selector, mode in PRESETS[args.preset]:
                if selector is None:
                    shared = shared or pipeline.build_selection(
                        args.source, seed, args.hops, args.selector, args.budget, args.per_relation)
                    sel = shared
                else:
                    sel = pipeline.build_selection(args.source, seed, args.hops, selector, args.budget,
                                                   args.per_relation)
                run = pipeline.narrate(sel["selection_id"], mode, args.sentences, selection=sel)
                lanes.append({"lane": key, "selection": sel, "run": run})
            first = lanes[0]["selection"]
            pipeline.save_gallery({
                "id": entry_id, "title": first["seed"]["label"], "source": args.source,
                "source_title": first["source_title"], "preset": args.preset,
                "seed": first["seed"], "popularity": first["popularity"],
                "hops": args.hops, "created": time.strftime("%Y-%m-%dT%H:%M:%S"), "lanes": lanes,
            })
            done += 1
            leak = [ln["run"]["metrics"]["leakage_rate"] for ln in lanes]
            print(f"ok    {seed}  ({time.time() - t0:.0f}s, leakage A={leak[0]} B={leak[1]})")
        except (KeyError, ValueError, SparqlError, LLMError) as exc:
            failed.append(seed)
            print(f"FAIL  {seed}: {exc}", file=sys.stderr)
    print(f"\n{done} prepared, {len(failed)} failed" + (f": {', '.join(failed)}" if failed else ""))
    return 1 if failed and not done else 0


if __name__ == "__main__":
    sys.exit(main())
