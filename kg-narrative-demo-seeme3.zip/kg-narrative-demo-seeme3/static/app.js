"use strict";

/* ------------------------------------------------------------------ state */

const $ = (id) => document.getElementById(id);
const state = {
  config: null,
  lanes: [],        // [{key, cfg, selection, run}]
  net: null, nodes: null, edges: null, member: new Map(), split: false,
  active: null,     // {lane, claim}
};

const HOP_COLORS = { 1: "#4b6a88", 2: "#8fa6ba", 3: "#c3cfda" };
const EDGE_BASE = "#9aa7b3";
const LABEL_HELP = {
  supported: "One supplied triple states it.",
  derived: "Follows from supplied triples by a fixed rule (subclass, domain, range, containment).",
  entailed: "The verifier judged it to follow from several triples. Model judgement, not a rule.",
  glue: "Connective wording: time order, cause or emphasis the graph does not state.",
  leakage: "Not supplied, but true in the full knowledge graph: it came from the model's memory.",
  not_in_kg: "Not supplied and not found in the full graph: invented, or missing from the KG.",
  unchecked: "Not supplied, and the full-graph lookup could not run.",
};

const cssVar = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
const labelColor = (label) => cssVar(`--${label}`) || "#5a6674";
const labelName = (id) => (state.config.labels.find((l) => l.id === id) || { label: id }).label;
const effective = (claim) => claim.human_label || claim.label;
const pct = (v) => (v === null || v === undefined ? "n/a" : `${Math.round(v * 100)}%`);

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "style") node.setAttribute("style", v);
    else if (k.startsWith("data-") || k.startsWith("aria-") || k === "role") node.setAttribute(k, v);
    else node[k] = v;
  }
  for (const c of children) if (c !== null && c !== undefined && c !== false) node.append(c);
  return node;
}

async function api(path, body) {
  const resp = await fetch(path, {
    method: body ? "POST" : "GET",
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = {};
  try { data = await resp.json(); } catch (_) { /* non-JSON error page */ }
  if (!resp.ok) throw new Error(data.error || `Request failed with HTTP ${resp.status}`);
  return data;
}

function setStatus(message, isError = false) {
  $("status").textContent = message;
  $("status").classList.toggle("error", isError);
}

function storeGet(key) { try { return localStorage.getItem(key) || ""; } catch (_) { return ""; } }
function storeSet(key, value) { try { localStorage.setItem(key, value); } catch (_) { /* storage off */ } }

/* ------------------------------------------------------------------ init */

async function init() {
  try {
    state.config = await api("/api/config");
  } catch (err) {
    setStatus(`Could not reach the server: ${err.message}`, true);
    return;
  }
  const c = state.config;
  for (const s of c.sources) $("source").append(el("option", { value: s.id, textContent: s.label }));
  document.querySelectorAll(".lane-settings").forEach((fs, i) => {
    const sel = fs.querySelector(".selector");
    for (const s of c.selectors) sel.append(el("option", { value: s.id, textContent: s.label }));
    sel.value = c.selectors.some((s) => s.id === "connected-ppr") ? "connected-ppr" : c.selectors[0].id;
    const mode = fs.querySelector(".mode");
    for (const m of c.modes) mode.append(el("option", { value: m.id, textContent: m.label, title: m.help }));
    mode.value = i === 0 ? "graph_only" : "closed_book";
  });
  for (const l of c.labels) $("human-label").append(el("option", { value: l.id, textContent: l.label }));
  $("annotator").value = storeGet("kgn-annotator");

  const help = $("label-help");
  for (const l of c.labels) {
    help.append(el("dt", { class: `lbl-${l.id}`, style: `--c: var(--${l.id})` }, el("span", { class: "swatch" }), l.label),
                el("dd", { textContent: LABEL_HELP[l.id] || "" }));
  }

  const notes = [`Writer ${c.model}, verifier ${c.verifier_model}`];
  if (c.offline) notes.push("offline fixture");
  if (c.mock) notes.push("mock LLM output");
  $("runtime").textContent = notes.join("; ");

  $("compare").addEventListener("change", syncCompare);
  syncCompare();
  await loadGalleryList();
}

function syncCompare() {
  document.querySelector('.lane-settings[data-lane="B"]').disabled = !$("compare").checked;
}

function laneSettings() {
  const out = [];
  for (const fs of document.querySelectorAll(".lane-settings")) {
    if (fs.disabled) continue;
    out.push({
      key: fs.dataset.lane,
      selector: fs.querySelector(".selector").value,
      budget: Number(fs.querySelector(".budget").value),
      mode: fs.querySelector(".mode").value,
    });
  }
  return out;
}

/* ------------------------------------------------------------------ gallery */

const PRESET_NAMES = { memory: "graph-only vs closed-book", prompts: "graph-only vs plain", selectors: "top-k vs connected" };

async function loadGalleryList() {
  let items = [];
  try { items = await api("/api/gallery"); } catch (_) { items = []; }
  const g = $("gallery");
  g.replaceChildren(el("option", { value: "", textContent: items.length ? "Choose an example" : "No examples yet" }));
  for (const it of items) {
    const pop = it.popularity ? `, ${it.popularity.value} ${it.popularity.measure}` : "";
    g.append(el("option", { value: it.id, textContent: `${it.title} (${it.source}; ${PRESET_NAMES[it.preset] || it.preset}${pop})` }));
  }
  g.disabled = !items.length;
  $("gallery-empty").hidden = items.length > 0;
}

$("gallery").addEventListener("change", async () => {
  const id = $("gallery").value;
  if (!id) return;
  setStatus("Loading prepared example...");
  try {
    const entry = await api(`/api/gallery/${encodeURIComponent(id)}`);
    state.lanes = entry.lanes.map((l) => ({ key: l.lane, cfg: null, selection: l.selection, run: l.run }));
    syncFormFromLanes(entry);
    renderAll();
    $("narrate-btn").disabled = true;
    setStatus(`Prepared example: ${entry.title}, ${entry.source_title}.`);
  } catch (err) {
    setStatus(err.message, true);
  }
});

// Show a prepared example's settings in the form, so "Build subgraph" reproduces it.
function syncFormFromLanes(entry) {
  $("seed").value = entry.seed.label;
  if ([...$("source").options].some((o) => o.value === entry.source)) $("source").value = entry.source;
  if (entry.hops) $("hops").value = String(entry.hops);
  const cap = entry.lanes[0].selection.per_relation;
  $("per-relation").value = cap === null || cap === undefined ? 0 : cap;
  $("compare").checked = entry.lanes.length > 1;
  syncCompare();
  for (const l of entry.lanes) {
    const fs = document.querySelector(`.lane-settings[data-lane="${l.lane}"]`);
    if (!fs) continue;
    fs.querySelector(".selector").value = l.selection.selector;
    fs.querySelector(".budget").value = l.selection.budget;
    fs.querySelector(".mode").value = l.run.mode;
  }
}

/* ------------------------------------------------------------------ build and narrate */

$("build-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const lanes = laneSettings();
  $("build-btn").disabled = true;
  $("narrate-btn").disabled = true;
  $("gallery").value = "";
  setStatus(state.config.offline ? "Selecting triples from the fixture..." : "Querying the knowledge graph and selecting triples...");
  try {
    const built = [];
    for (const l of lanes) {
      const same = built.find((b) => b.cfg.selector === l.selector && b.cfg.budget === l.budget);
      const selection = same ? same.selection : await api("/api/subgraph", {
        source: $("source").value, seed: $("seed").value, hops: Number($("hops").value),
        selector: l.selector, budget: l.budget, per_relation: Number($("per-relation").value),
      });
      built.push({ key: l.key, cfg: l, selection, run: null });
    }
    state.lanes = built;
    renderAll();
    $("narrate-btn").disabled = false;
    const sel = built[0].selection;
    setStatus(`${sel.triples.length} triples around ${sel.seed.label}; ${sel.derived.length} more derived by rules.`);
  } catch (err) {
    setStatus(err.message, true);
  } finally {
    $("build-btn").disabled = false;
  }
});

$("narrate-btn").addEventListener("click", async () => {
  if (!state.lanes.length || !state.lanes[0].cfg) return;
  $("narrate-btn").disabled = true;
  $("build-btn").disabled = true;
  const what = state.lanes.length > 1 ? "both narratives" : "the narrative";
  const started = Date.now();
  const tick = () => setStatus(`Writing and auditing ${what}: ${Math.round((Date.now() - started) / 1000)} s. ` +
    "Usually 30 to 120 s; the server terminal shows each step.");
  tick();
  const timer = setInterval(tick, 1000);
  const sentences = Number($("sentences").value);
  const results = await Promise.allSettled(state.lanes.map((l) => api("/api/narrate", {
    selection_id: l.selection.selection_id, mode: l.cfg.mode, sentences,
  })));
  clearInterval(timer);
  const errors = [];
  results.forEach((r, i) => {
    if (r.status === "fulfilled") state.lanes[i].run = r.value;
    else errors.push(`Setting ${state.lanes[i].key}: ${r.reason.message}`);
  });
  selectClaim(null);
  renderLanes();
  renderLegend();
  if (errors.length) setStatus(errors.join(" "), true);
  else setStatus(state.lanes.map((l) => `${state.lanes.length > 1 ? l.key + ": " : ""}leakage ${pct(l.run.metrics.leakage_rate)}`).join(", ") + ".");
  $("narrate-btn").disabled = false;
  $("build-btn").disabled = false;
});

/* ------------------------------------------------------------------ rendering */

function renderAll() {
  selectClaim(null);
  renderGraph();
  renderDiagnostics();
  renderLanes();
  renderLegend();
}

function wrap(text, width = 22) {
  const lines = [];
  let line = "";
  for (const w of String(text).split(" ")) {
    if ((line + " " + w).trim().length > width && line) { lines.push(line); line = w; }
    else line = (line + " " + w).trim();
  }
  lines.push(line);
  return lines.slice(0, 3).join("\n");
}

function nodeStyle(n, seedId) {
  if (n.id === seedId) {
    return { shape: "dot", size: 20, color: { background: "#17202b", border: "#17202b" },
             font: { size: 15, color: "#17202b", face: "Public Sans", bold: true } };
  }
  if (n.kind === "literal") {
    return { shape: "box", color: { background: "#f4f6f8", border: "#cbd2d8" }, borderWidth: 1,
             margin: 6, font: { size: 12, color: "#3d4957", face: "Public Sans" } };
  }
  const color = HOP_COLORS[n.hop] || HOP_COLORS[3];
  return { shape: "dot", size: n.hop === 1 ? 12 : 9, color: { background: color, border: color },
           font: { size: 13, color: "#17202b", face: "Public Sans" } };
}

// Which settings selected each candidate triple (keyed by candidate id).
function computeMembership() {
  const member = new Map();
  for (const l of state.lanes) {
    for (const t of l.selection.triples) {
      if (!member.has(t.cid)) member.set(t.cid, { t, lanes: new Set() });
      member.get(t.cid).lanes.add(l.key);
    }
  }
  state.member = member;
  state.split = new Set(state.lanes.map((l) => l.selection.selection_id)).size > 1;
}

function baseEdge(cid) {
  const info = state.member.get(cid);
  const only = state.split && info.lanes.size === 1 ? [...info.lanes][0] : null;
  return {
    id: cid, width: state.split && !only ? 2.5 : 1,
    dashes: only === "B" ? [6, 5] : false,
    color: { color: only ? "#b7c1ca" : EDGE_BASE, opacity: 1 },
    font: { color: "#5a6674" },
  };
}

function renderGraph() {
  if (!state.lanes.length) return;
  $("graph-empty").hidden = true;
  computeMembership();
  const seedId = state.lanes[0].selection.seed.uri;
  const nodeMap = new Map();
  for (const l of state.lanes) for (const n of l.selection.nodes) nodeMap.set(n.id, n);

  const nodes = [...nodeMap.values()].map((n) => ({ id: n.id, label: wrap(n.label), title: n.label, ...nodeStyle(n, seedId), opacity: 1 }));
  const edges = [...state.member.entries()].map(([cid, info]) => ({
    ...baseEdge(cid),
    from: info.t.s, to: info.t.o, label: info.t.p_label,
    title: `${info.t.s_label} | ${info.t.p_label} | ${info.t.o_label}`,
    arrows: { to: { enabled: true, scaleFactor: 0.5 } },
    font: { size: 11, color: "#5a6674", strokeWidth: 3, strokeColor: "#eceff1", face: "Public Sans" },
    smooth: { type: "continuous" },
  }));
  state.nodes = new vis.DataSet(nodes);
  state.edges = new vis.DataSet(edges);
  if (state.net) state.net.destroy();
  state.net = new vis.Network($("graph"), { nodes: state.nodes, edges: state.edges }, {
    physics: { solver: "barnesHut", barnesHut: { springLength: 130, avoidOverlap: 0.3 }, stabilization: { iterations: 250 } },
    interaction: { hover: true, tooltipDelay: 150 },
  });
  state.net.once("stabilizationIterationsDone", () => state.net.setOptions({ physics: false }));
  state.net.on("click", (p) => {
    if (p.edges.length && !p.nodes.length) edgeClicked(p.edges[0]);
    else if (!p.edges.length && !p.nodes.length) selectClaim(null);
  });

  $("graph-key").hidden = !state.split;
  $("graph-key").textContent = state.split ? "Thick: selected in both settings. Thin: only in A. Dashed: only in B." : "";
}

function renderDiagnostics() {
  const box = $("diagnostics");
  box.replaceChildren();
  if (!state.lanes.length) return;
  const lanes = state.split ? state.lanes : state.lanes.slice(0, 1);
  const rows = [
    ["Candidate triples", (d) => d.candidate_triples],
    ["Selected", (d) => d.triples],
    ["Derived by rules", (d) => d.derived_triples],
    ["Connected to seed", (d) => pct(d.connected_fraction)],
    ["Literals", (d) => pct(d.literal_fraction)],
    ["Relation diversity", (d) => pct(d.relation_diversity)],
    ["Most frequent relation", (d) => (d.top_relation ? `${d.top_relation}, ${pct(d.top_relation_share)}` : "n/a")],
    ["Hop 1 / 2 / 3", (d) => ["1", "2", "3"].map((h) => (d.hop_counts || {})[h] || 0).join(" / ")],
  ];
  if (lanes.some((l) => l.selection.diagnostics.oov_entities !== undefined)) {
    rows.push(["Not in wiki2vec", (d) => (d.oov_entities === undefined ? "n/a" : `${d.oov_entities}/${d.entities}`)]);
  }
  const table = el("table", { class: "diag" });
  table.append(el("thead", {}, el("tr", {}, el("th", { textContent: "Subgraph" }),
    ...lanes.map((l) => el("th", { textContent: lanes.length > 1 ? l.key : "" })))));
  const tbody = el("tbody");
  for (const [name, fn] of rows) {
    tbody.append(el("tr", {}, el("td", { textContent: name }),
      ...lanes.map((l) => el("td", { textContent: String(fn(l.selection.diagnostics)) }))));
  }
  table.append(tbody);
  box.append(table);
  const first = state.lanes[0].selection;
  if (first.popularity) box.append(el("p", { class: "hint", textContent: `Seed popularity: ${first.popularity.value} ${first.popularity.measure}.` }));
  if (first.closure_note) box.append(el("p", { class: "hint", textContent: first.closure_note }));
}

function renderLegend() {
  const ul = $("legend");
  ul.replaceChildren();
  const anyRun = state.lanes.some((l) => l.run);
  ul.hidden = !anyRun;
  if (!anyRun) return;
  for (const l of state.config.labels) {
    ul.append(el("li", { class: `lbl-${l.id}`, style: `--c: var(--${l.id})` }, el("span", { class: "swatch" }), l.label));
  }
}

function laneHeading(lane) {
  const sel = lane.selection;
  let mode = "";
  if (lane.run) mode = lane.run.mode_label;
  else if (lane.cfg) mode = state.config.modes.find((m) => m.id === lane.cfg.mode).label;
  const who = state.lanes.length > 1 ? el("strong", { textContent: `Setting ${lane.key}. ` }) : null;
  return el("p", { class: "lane-head" }, who, `${sel.selector_label}, ${sel.triples.length} triples; ${mode.toLowerCase()} prompt.`);
}

function renderLanes() {
  const box = $("lanes");
  box.replaceChildren();
  box.style.setProperty("--lanes", Math.max(1, state.lanes.length));
  for (const lane of state.lanes) {
    const art = el("article", { class: "lane", "data-lane": lane.key });
    art.append(laneHeading(lane));
    if (!lane.run) art.append(el("p", { class: "placeholder", textContent: "Select Write and audit to generate this narrative." }));
    else art.append(el("h3", { textContent: lane.run.title }), narrativeBody(lane), metricsTable(lane.run));
    box.append(art);
  }
}

function claimNode(lane, claim, text) {
  const lbl = effective(claim);
  const node = text !== undefined
    ? el("span", { class: `claim lbl-${lbl}`, tabIndex: 0, textContent: text, role: "button" })
    : el("button", { class: `claim-mark lbl-${lbl}`, type: "button", textContent: "+", title: claim.claim });
  node.dataset.lane = lane.key;
  node.dataset.claim = claim.index;
  node.setAttribute("aria-label", `${claim.claim} (${labelName(lbl)})`);
  node.addEventListener("click", () => selectClaim(lane, claim));
  node.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); selectClaim(lane, claim); }
  });
  return node;
}

function narrativeBody(lane) {
  const run = lane.run;
  const body = el("p", { class: "body" });
  const byIndex = Object.fromEntries(run.claims.map((c) => [c.index, c]));
  run.sentences.forEach((s, i) => {
    for (const seg of s.segments) {
      body.append(seg.claim === null ? document.createTextNode(seg.text) : claimNode(lane, byIndex[seg.claim], seg.text));
    }
    for (const c of run.claims.filter((c) => c.sentence === i && !c.rendered)) body.append(claimNode(lane, c));
    body.append(" ");
  });
  return body;
}

function metricsTable(run) {
  const m = run.metrics;
  const rows = [
    ["Claims", m.claims],
    ["Grounded precision", pct(m.grounded_precision)],
    ["Rule-backed share of grounded", pct(m.rule_backed)],
    ["Leakage rate", pct(m.leakage_rate)],
    ["Not found in KG", m.counts.not_in_kg],
    ["Triple coverage", pct(m.triple_coverage)],
    ["Glue share", pct(m.glue_share)],
  ];
  const table = el("table", { class: "metrics" });
  for (const [k, v] of rows) table.append(el("tr", {}, el("td", { textContent: k }), el("td", { textContent: String(v) })));
  return table;
}

/* ------------------------------------------------------------------ highlighting */

function resetHighlight() {
  if (!state.edges) return;
  state.edges.update([...state.member.keys()].map(baseEdge));
  state.nodes.update(state.nodes.getIds().map((id) => ({ id, opacity: 1 })));
  document.querySelectorAll(".linked").forEach((n) => n.classList.remove("linked"));
}

function highlightCids(cids, color) {
  if (!state.edges) return;
  const set = new Set(cids);
  const keep = new Set([state.lanes[0].selection.seed.uri]);
  for (const cid of set) {
    const info = state.member.get(cid);
    if (info) { keep.add(info.t.s); keep.add(info.t.o); }
  }
  state.edges.update([...state.member.keys()].map((cid) => set.has(cid)
    ? { id: cid, width: 4, dashes: false, color: { color, opacity: 1 }, font: { color: "#17202b" } }
    : { id: cid, width: 1, color: { color: EDGE_BASE, opacity: 0.18 }, font: { color: "rgba(90,102,116,0.2)" } }));
  state.nodes.update(state.nodes.getIds().map((id) => ({ id, opacity: keep.has(id) ? 1 : 0.22 })));
}

const tidToCid = (lane, tid) => (lane.selection.triples.find((t) => t.tid === tid) || {}).cid;

function selectClaim(lane, claim) {
  document.querySelectorAll("[data-claim].active").forEach((n) => n.classList.remove("active"));
  resetHighlight();
  if (!lane || !claim) {
    state.active = null;
    $("detail").hidden = true;
    $("detail-empty").hidden = false;
    return;
  }
  state.active = { lane, claim };
  document.querySelectorAll(`[data-lane="${lane.key}"][data-claim="${claim.index}"]`).forEach((n) => n.classList.add("active"));
  highlightCids(claim.evidence_triples.map((t) => tidToCid(lane, t)).filter(Boolean), labelColor(effective(claim)));
  renderDetail(lane, claim);
}

function edgeClicked(cid) {
  selectClaim(null);
  highlightCids([cid], "#17202b");
  const parts = [];
  for (const lane of state.lanes) {
    const t = lane.selection.triples.find((x) => x.cid === cid);
    const name = state.lanes.length > 1 ? `Setting ${lane.key}` : "This triple";
    if (!t) { parts.push(`${name}: not selected.`); continue; }
    if (!lane.run) { parts.push(`${name}: ${t.tid}.`); continue; }
    const using = lane.run.claims.filter((c) => c.evidence_triples.includes(t.tid));
    using.forEach((c) => document.querySelectorAll(`[data-lane="${lane.key}"][data-claim="${c.index}"]`)
      .forEach((n) => n.classList.add("linked")));
    parts.push(using.length
      ? `${name}: ${t.tid} supports ${using.length} claim${using.length > 1 ? "s" : ""}, shaded in the text.`
      : `${name}: ${t.tid} is not used by any claim.`);
  }
  setStatus(parts.join(" "));
}

function tripleItem(id, t, rule) {
  return el("li", {}, el("span", { class: "tid", textContent: id }), `${t.s_label} | ${t.p_label} | ${t.o_label}`,
    rule ? el("span", { class: "rule", textContent: rule }) : null);
}

function renderDetail(lane, claim) {
  $("detail-empty").hidden = true;
  $("detail").hidden = false;
  $("detail-lane").textContent = state.lanes.length > 1
    ? `Setting ${lane.key}, sentence ${claim.sentence + 1}` : `Sentence ${claim.sentence + 1}`;
  $("detail-claim").textContent = claim.claim;

  const lbl = $("detail-label");
  lbl.replaceChildren("Automatic label: ", el("strong", { style: `--c: var(--${claim.label})`, textContent: labelName(claim.label) }), ".");
  if (claim.human_label) {
    lbl.append(" Your label: ", el("strong", { style: `--c: var(--${claim.human_label})`, textContent: labelName(claim.human_label) }), ".");
  }

  const ev = $("detail-evidence");
  ev.replaceChildren();
  const tById = Object.fromEntries(lane.selection.triples.map((t) => [t.tid, t]));
  const dById = Object.fromEntries((lane.selection.derived || []).map((d) => [d.did, d]));
  if (claim.evidence.length) {
    const ul = el("ul", { class: "evidence" });
    for (const id of claim.evidence) {
      if (tById[id]) ul.append(tripleItem(id, tById[id]));
      else if (dById[id]) ul.append(tripleItem(id, dById[id], `${dById[id].rule} rule, from ${dById[id].from.join(" + ")}`));
    }
    ev.append(el("p", { class: "note", textContent: "Evidence" }), ul);
    const base = claim.evidence_triples.filter((t) => !claim.evidence.includes(t) && tById[t]);
    if (base.length) {
      const ul2 = el("ul", { class: "evidence" });
      for (const tid of base) ul2.append(tripleItem(tid, tById[tid]));
      ev.append(el("p", { class: "note", textContent: "Supplied triples the rules start from" }), ul2);
    }
    if (claim.citation_ok === false) ev.append(el("p", { class: "note", textContent: "The writer did not cite all of these triples for this sentence." }));
  } else if (claim.label !== "glue") {
    ev.append(el("p", { class: "note", textContent: "No supplied or derived triple supports this claim." }));
  }

  const or = $("detail-oracle");
  or.replaceChildren();
  const o = claim.oracle;
  if (o) {
    if (o.found && o.found.length) {
      const lead = o.status === "leakage"
        ? `Found in the full knowledge graph (${o.how}), but not given to the writer:` : "The full-graph lookup found:";
      const ul = el("ul", { class: "evidence" });
      for (const f of o.found) ul.append(el("li", { textContent: f }));
      or.append(el("p", { class: "note", textContent: lead }), ul);
    }
    if (o.reason) or.append(el("p", { class: "note", textContent: `Full-graph lookup: ${o.reason}.` }));
  }

  $("human-label").value = effective(claim);
  $("human-note").value = claim.human_note || "";
}

$("annotate-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!state.active) return;
  const { lane, claim } = state.active;
  const annotator = $("annotator").value.trim();
  storeSet("kgn-annotator", annotator);
  try {
    const res = await api("/api/annotate", {
      run_id: lane.run.run_id, claim_index: claim.index, label: $("human-label").value,
      note: $("human-note").value, annotator,
    });
    claim.human_label = res.human_label;
    claim.human_note = $("human-note").value.trim();
    document.querySelectorAll(`[data-lane="${lane.key}"][data-claim="${claim.index}"]`).forEach((n) => {
      n.className = n.className.replace(/lbl-\S+/, `lbl-${claim.human_label}`);
    });
    renderDetail(lane, claim);
    setStatus("Label saved to data/annotations.jsonl.");
  } catch (err) {
    setStatus(err.message, true);
  }
});

init();
